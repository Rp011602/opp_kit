# OpportunityKit — Smart Student Eligibility Checker
> **SETU 2026 Hackathon — Round 2 | Problem Statement PS-03: Forge Realm**  
> *A transparent, explainable, and actionable decision-support platform connecting students with internships, scholarships, and competitions.*

---

## 🚀 Live Demo & Quick Overview

**OpportunityKit** is a responsive web application designed to help college students instantly assess and understand their eligibility for career opportunities without black-box rejections. 

Unlike traditional platforms that simply show "Ineligible" without context, OpportunityKit conducts a transparent, rule-by-rule audit, distinguishes between **missing information** and **genuine qualification mismatches**, and provides an interactive **action checklist** to help students close the gaps.

---

## 🎯 Problem Statement (PS-03: Forge Realm)

College students miss out on life-changing scholarships, tech internships, and prestigious hackathons because:
1. **Ambiguous Criteria:** Requirements are scattered across long PDFs, brochures, and eligibility forms.
2. **Black-box Rejections:** Portals reject students without explaining *why* they failed (e.g. was it CGPA, branch, or a missing document?).
3. **Premature Disqualification:** Students are marked ineligible simply because they haven't uploaded an optional file or filled in non-mandatory profile fields.
4. **No Actionable Feedback:** Students don't know what concrete steps (skills to learn, documents to obtain) will make them eligible.

---

## ✨ Core Features & Technical Highlights

### 1. 👤 Student Profile Foundation
- Comprehensive student profile capturing:
  - Academic Year (1st, 2nd, 3rd, 4th, Postgraduate)
  - Degree & Branch (CSE, IT, ECE, Mechanical, etc.)
  - Cumulative CGPA (with scale validation)
  - Technical & Soft Skills (clickable popular tags + custom input)
  - Verified Documents Available (Resume, Transcripts, Income Certificate, Bonafide, etc.)
  - Public Links (GitHub repository & portfolio)
  - Socio-Economic & Team Data (Annual family income in LPA, hackathon team size)
- **Instant Testing Presets:** 1-click test profiles (e.g., Aarav Sharma, Pooja Patel, Rohan Verma) for fast hackathon judging.
- **Client-Side Persistence:** Automatically saves to browser `localStorage` — 100% private with no required account or backend latency.

### 2. 🧭 Opportunity Selection & Custom Entry
- **Three Core Categories:**
  - **Internships:** Big-tech SDE, FinTech frontend, ISRO space research.
  - **Scholarships:** Reliance Foundation grant, Adobe Women-in-Tech, National Means scholarship.
  - **Competitions:** Smart India Hackathon (SIH 2026), SETU 2026 Hackathon (Forge Realm), Flipkart GRiD.
- **Custom Opportunity Creator:** Users and placement coordinators can manually define custom opportunities with specific eligibility cutoffs, required skills, mandatory documents, and income caps.

### 3. 🧩 Dynamic Custom Requirements Engine
OpportunityKit eliminates the constraint of rigid, hardcoded forms:
- **"Add Custom Requirement" Builder:** Supports creating and editing non-standard eligibility rules for any opportunity:
  - **Number:** Numeric threshold checks with customizable operators (`≥ Minimum`, `≤ Maximum`, `== Exact`), e.g., *Prior Project Duration ≥ 3 months*, *Maximum Age ≤ 24*.
  - **Text:** Flexible substring or exact string matching, e.g., *State Domicile contains "Karnataka"*, *Gender Eligibility*.
  - **Skill:** Dynamically checks student skills or answers, e.g., *Proficiency in Docker / PyTorch*.
  - **Document:** Dynamically verifies paperwork preparation, e.g., *No Objection Certificate (NOC)*.
  - **Yes/No:** Logical verification conditions, e.g., *Has Valid Indian Passport*, *Female Teammate Inclusion*.
- **Dynamic Student Form Generation:** Automatically renders the appropriate responsive input control (number input, text input, checkbox, or Yes/No buttons) in the student profile.
- **Inline Clarification Box:** In the Eligibility Checker, if a custom requirement is missing or student needs to clarify, they can answer or update it right inside the requirement card and click **"Save & Recheck"** for instantaneous recalculation!
- **Zero-Guessing Fairness Rule:** Unanswered custom requirements are marked **`MISSING INFO`** rather than automatic failure.

### 4. 🧠 Smart Rule-Based Eligibility Engine
OpportunityKit uses deterministic, explainable rule logic (`src/utils/eligibilityEngine.js`):
- **MATCH (Green):** The requirement is fully satisfied.
- **MISMATCH (Rose):** Profile data exists and directly violates the criterion (e.g., student CGPA 7.2 < required 8.0, or work experience 1 month < 3 months).
- **MISSING INFO (Amber):** The student hasn't entered this field yet. **Crucial Innovation:** *Unknown data is never penalized as a failure.*
- Each requirement displays:
  - Requirement Label
  - Expected Criterion
  - Student's Current Value
  - Status Badge
  - Natural-language explanation

### 5. 📊 Results Dashboard & Readiness Score
- Visual gauge with **Readiness Percentage**:
  $$\text{Readiness} = \left(\frac{\text{Matched Criteria}}{\text{Total Applicable Criteria}}\right) \times 100\%$$
- Summary counts for Matched, Mismatched, and Missing Info.
- Overall verdict diagnosis:
  - *Strong Match (100% Ready)*
  - *Conditionally Eligible (Missing Details)*
  - *Partially Eligible (Action Required)*
  - *Eligibility Gaps Detected*
- Filter pills to inspect only mismatches or missing information.
- Quick buttons to **Share Report (copy to clipboard)** and **Print / PDF Export**.

### 5. ✅ Personalized Improvement Checklist
- Dynamically converts detected gaps and missing documents into actionable tasks.
- Interactive checkboxes allow students to check off tasks as they prepare.
- Live progress indicator tracking task completion.
- Direct shortcut to edit and recalculate profile readiness.

### 6. 🏫 "For Colleges" Section (Future Business Potential)
- **Student-First MVP Design:** Deliberately built without teacher logins, admin portals, or complex role switches to maintain maximum speed, privacy, and zero-friction usability for students.
- **Future Paying Customers (Colleges & TPOs):** Clearly explains the institutional subscription vision:
  - **Batch-Wide Opportunity Screening:** 1-click query across 1,000+ students when recruiters visit with strict criteria.
  - **Campus Skill Gap Diagnostics:** Aggregated cohort analytics to help college placement cells organize targeted training.
  - **Automated Shortlist Export:** Verified student rosters formatted to corporate hiring specifications.
  - **Pricing Model:** B2B annual campus subscription (₹25,000 – ₹50,000 / year per campus) subsidizing free student access.
- **Explicit Scope:** Labeled as non-functional conceptual roadmap preview for SETU 2026.

---

## 🛠️ Tech Stack

- **Framework:** React 18 + Vite 5
- **Styling:** Tailwind CSS with custom navy & blue design system
- **Icons:** Lucide React
- **Storage:** HTML5 `localStorage` API
- **Testing:** Pure Node.js unit test suite (`16/16 passing`)
- **Zero Heavy Dependencies:** No heavy backends, no paid API keys, no external database latency.

---

## 📦 Project Structure

```
setu/
├── index.html                   # HTML entry point with Plus Jakarta Sans & Inter
├── package.json                 # Dependencies and build scripts
├── postcss.config.js            # PostCSS configuration
├── tailwind.config.js           # Tailwind theme configuration
├── vite.config.js               # Vite bundler configuration
├── src/
│   ├── main.jsx                 # React root mount
│   ├── App.jsx                  # Main application orchestrator
│   ├── index.css                # Tailwind directives & custom scrollbars
│   ├── types/
│   │   └── defaultProfile.js    # Data schemas, presets & option lists
│   ├── data/
│   │   └── sampleOpportunities.js # Realistic internships, scholarships & hackathons
│   ├── utils/
│   │   ├── eligibilityEngine.js # Deterministic rule-based evaluation logic
│   │   └── eligibilityEngine.test.js # Comprehensive unit test suite
│   └── components/
│       ├── Navbar.jsx           # Top navigation & readiness pill
│       ├── OpportunityList.jsx  # Category tabs, search & filters
│       ├── OpportunityCard.jsx  # Opportunity cards with criteria preview
│       ├── OpportunityModal.jsx # Detailed requirement modal
│       ├── CustomOpportunityModal.jsx # Manual opportunity form
│       ├── StudentProfileForm.jsx     # Profile editor & presets
│       ├── EligibilityResults.jsx     # Dashboard, readiness & breakdown
│       ├── ActionChecklist.jsx        # Interactive next-step checklist
│       ├── FutureMonetization.jsx     # Monetization & B2B/B2C roadmap
│       └── Footer.jsx           # Hackathon credits & cache reset
└── README.md                    # Project documentation
```

---

## ⚡ Getting Started Locally

### Prerequisites
- Node.js (v18 or higher recommended)
- npm (v9 or higher)

### Installation & Run

1. Clone or navigate to the repository directory:
   ```bash
   cd setu
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Run the development server:
   ```bash
   npm run dev
   ```
   Open your browser and navigate to `http://localhost:5173`.

4. Run the automated unit tests:
   ```bash
   node src/utils/eligibilityEngine.test.js
   ```

5. Build for production:
   ```bash
   npm run build
   ```
   The production-ready bundle will be generated in the `dist/` directory.

---

## 🌐 Deployment Instructions

OpportunityKit has no server dependencies and deploys easily on modern static hosting platforms:

### Deploying to Vercel
1. Install Vercel CLI: `npm i -g vercel` (or connect your GitHub repository on [vercel.com](https://vercel.com)).
2. Run:
   ```bash
   vercel
   ```
3. Set the build settings:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`

### Deploying to Netlify
1. Drag and drop the `dist/` folder into the Netlify Web UI or connect via git.
2. Build command: `npm run build`
3. Publish directory: `dist`

---

## 🏆 Innovation & Hackathon Alignment

| Hackathon Criterion | OpportunityKit Implementation |
|---|---|
| **Problem Match** | Direct solution for SETU 2026 PS-03 (Forge Realm) enabling student career navigation. |
| **Explainability** | Replaces opaque rejection with rule-by-rule breakdown showing expected vs actual values. |
| **Fairness** | Explicitly separates **MISSING INFO** from **MISMATCH**, preventing unjust disqualifications. |
| **Actionability** | Generates tailored tasks (courses, documents, links) rather than just passive results. |
| **Feasibility & Speed** | Pure client-side architecture loads instantaneously, works offline, and requires zero cloud infrastructure costs. |

---

*Developed for SETU 2026 Hackathon (Forge Realm • PS-03).*
