/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#f0f4f9',
          100: '#e1e9f2',
          200: '#c3d3e6',
          300: '#9bb8d5',
          400: '#6d97c0',
          500: '#4c7aa9',
          600: '#38618e',
          700: '#2c4d72',
          800: '#1e344e',
          900: '#0f1f32',
          950: '#0a1420',
        }
      }
    },
  },
  plugins: [],
}
