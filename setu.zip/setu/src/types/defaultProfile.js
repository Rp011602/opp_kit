export const DEFAULT_BRANCHES = [
  "Computer Science & Engineering (CSE)",
  "Information Technology (IT)",
  "Electronics & Communication Engineering (ECE)",
  "Electrical & Electronics Engineering (EEE)",
  "Mechanical Engineering (ME)",
  "Civil Engineering (CE)",
  "Artificial Intelligence & Data Science (AI & DS)",
  "Biotechnology",
  "Business & Commerce / Economics",
  "Sciences / Mathematics"
];

export const YEARS_OF_STUDY = [
  "1st Year",
  "2nd Year",
  "3rd Year",
  "4th Year",
  "Postgraduate / Masters"
];

export const AVAILABLE_DOCUMENTS = [
  "Updated Resume / CV",
  "College ID Card",
  "Semester Marksheets / Official Transcripts",
  "Annual Family Income Certificate",
  "Bonafide Student Certificate",
  "Letter of Recommendation (LOR)",
  "Government Photo ID (Aadhaar / Passport)"
];

export const COMMON_SKILLS = [
  "React",
  "JavaScript",
  "Python",
  "Data Structures & Algorithms",
  "Node.js",
  "Java",
  "C++",
  "SQL & Databases",
  "HTML/CSS",
  "Tailwind CSS",
  "Machine Learning",
  "Git & GitHub",
  "Cloud / AWS / Docker",
  "Figma / UI Design"
];

export const EMPTY_STUDENT_PROFILE = {
  fullName: "",
  email: "",
  yearOfStudy: "",
  branch: "",
  cgpa: "",
  skills: [],
  documents: [],
  githubUrl: "",
  portfolioUrl: "",
  familyIncomeLpa: "",
  teamSize: "",
  customResponses: {}
};

export const SAMPLE_STUDENT_PROFILES = [
  {
    id: "sample_tech_student",
    name: "Aarav Sharma (3rd Year CSE - Tech Oriented)",
    profile: {
      fullName: "Aarav Sharma",
      email: "aarav.sharma@college.edu",
      yearOfStudy: "3rd Year",
      branch: "Computer Science & Engineering (CSE)",
      cgpa: "8.4",
      skills: ["React", "JavaScript", "Python", "Data Structures & Algorithms", "Git & GitHub", "Tailwind CSS"],
      documents: ["Updated Resume / CV", "College ID Card", "Semester Marksheets / Official Transcripts"],
      githubUrl: "https://github.com/aaravsharma-dev",
      portfolioUrl: "https://aaravsharma.me",
      familyIncomeLpa: "7.5",
      teamSize: "3",
      customResponses: {
        "isro_cust_citizenship": "Yes",
        "isro_cust_lab_exp": "4",
        "adobe_cust_gender": "Male",
        "sih_cust_female_member": "Yes"
      }
    }
  },
  {
    id: "sample_scholarship_seeker",
    name: "Pooja Patel (2nd Year ECE - High Merit & Grant Seeker)",
    profile: {
      fullName: "Pooja Patel",
      email: "pooja.patel@engineering.ac.in",
      yearOfStudy: "2nd Year",
      branch: "Electronics & Communication Engineering (ECE)",
      cgpa: "9.1",
      skills: ["C++", "Python", "Data Structures & Algorithms", "Git & GitHub"],
      documents: [
        "Updated Resume / CV",
        "College ID Card",
        "Semester Marksheets / Official Transcripts",
        "Annual Family Income Certificate",
        "Bonafide Student Certificate"
      ],
      githubUrl: "https://github.com/pooja-patel",
      portfolioUrl: "",
      familyIncomeLpa: "3.2",
      teamSize: "1",
      customResponses: {
        "isro_cust_citizenship": "Yes",
        "isro_cust_lab_exp": "6",
        "adobe_cust_gender": "Female",
        "sih_cust_female_member": "Yes"
      }
    }
  },
  {
    id: "sample_first_year",
    name: "Rohan Verma (1st Year - Beginner / Needs Guidance)",
    profile: {
      fullName: "Rohan Verma",
      email: "rohan.v@campus.org",
      yearOfStudy: "1st Year",
      branch: "Computer Science & Engineering (CSE)",
      cgpa: "7.2",
      skills: ["Python", "HTML/CSS"],
      documents: ["College ID Card"],
      githubUrl: "",
      portfolioUrl: "",
      familyIncomeLpa: "",
      teamSize: "",
      customResponses: {}
    }
  }
];
