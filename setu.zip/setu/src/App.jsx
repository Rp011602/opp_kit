import React, { useState, useEffect, useMemo } from 'react';
import Navbar from './components/Navbar';
import OpportunityList from './components/OpportunityList';
import StudentProfileForm from './components/StudentProfileForm';
import EligibilityResults from './components/EligibilityResults';
import ForColleges from './components/ForColleges';
import StudentJourneyBanner from './components/StudentJourneyBanner';
import Footer from './components/Footer';
import OpportunityModal from './components/OpportunityModal';
import CustomOpportunityModal from './components/CustomOpportunityModal';

import { SAMPLE_OPPORTUNITIES } from './data/sampleOpportunities';
import { SAMPLE_STUDENT_PROFILES, EMPTY_STUDENT_PROFILE } from './types/defaultProfile';
import { evaluateEligibility } from './utils/eligibilityEngine';

const STORAGE_KEYS = {
  PROFILE: 'opportunitykit_student_profile',
  OPPORTUNITIES: 'opportunitykit_opportunities_list',
  SELECTED_OPP_ID: 'opportunitykit_selected_opp_id'
};

export default function App() {
  const [activeTab, setActiveTab] = useState('explore'); // 'explore' | 'profile' | 'checker' | 'colleges'
  const [isCustomModalOpen, setIsCustomModalOpen] = useState(false);
  const [opportunityToEdit, setOpportunityToEdit] = useState(null);
  const [viewingOppDetails, setViewingOppDetails] = useState(null);

  // Initialize Student Profile from localStorage (or default to sample tech student for instant testability)
  const [profile, setProfile] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Error reading profile from localStorage", e);
    }
    // Default to Aarav Sharma sample so judges/users can test right away
    return SAMPLE_STUDENT_PROFILES[0].profile;
  });

  // Initialize Opportunities from localStorage or default SAMPLE_OPPORTUNITIES
  const [opportunities, setOpportunities] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.OPPORTUNITIES);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Error reading opportunities from localStorage", e);
    }
    return SAMPLE_OPPORTUNITIES;
  });

  // Initialize Selected Opportunity
  const [selectedOppId, setSelectedOppId] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SELECTED_OPP_ID);
      if (saved) {
        return saved;
      }
    } catch (e) {
      console.error("Error reading selected opportunity from localStorage", e);
    }
    return SAMPLE_OPPORTUNITIES[0]?.id || null;
  });

  // Keep selectedOpp reference synchronized
  const selectedOpportunity = useMemo(() => {
    return opportunities.find(o => o.id === selectedOppId) || opportunities[0] || null;
  }, [opportunities, selectedOppId]);

  // Evaluate eligibility reactively whenever profile or selectedOpportunity changes
  const evaluationReport = useMemo(() => {
    if (!profile || !selectedOpportunity) return null;
    return evaluateEligibility(profile, selectedOpportunity);
  }, [profile, selectedOpportunity]);

  // Profile completeness score for navbar chip
  const profileCompleteness = useMemo(() => {
    if (!profile) return 0;
    let score = 0;
    if (profile.fullName) score += 10;
    if (profile.yearOfStudy) score += 15;
    if (profile.branch) score += 15;
    if (profile.cgpa) score += 15;
    if (profile.skills && profile.skills.length > 0) score += 20;
    if (profile.documents && profile.documents.length > 0) score += 15;
    if (profile.githubUrl) score += 10;
    return Math.min(100, score);
  }, [profile]);

  // Save profile changes to localStorage
  const handleSaveProfile = (updatedProfile) => {
    setProfile(updatedProfile);
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(updatedProfile));
    } catch (e) {
      console.error("Failed to save profile to localStorage", e);
    }
  };

  // Update specific custom answer (e.g. from inline clarification box in checker)
  const handleUpdateCustomResponse = (reqKey, value) => {
    const updatedProfile = {
      ...profile,
      customResponses: {
        ...(profile.customResponses || {}),
        [reqKey]: value
      }
    };
    handleSaveProfile(updatedProfile);
  };

  // Select opportunity and navigate to Checker
  const handleSelectOpportunity = (opp) => {
    setSelectedOppId(opp.id);
    try {
      localStorage.setItem(STORAGE_KEYS.SELECTED_OPP_ID, opp.id);
    } catch (e) {
      console.error("Failed to save selected opportunity id", e);
    }
    setActiveTab('checker');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Open modal to create or edit opportunity
  const handleOpenCustomModal = (oppToEdit = null) => {
    setOpportunityToEdit(oppToEdit);
    setIsCustomModalOpen(true);
  };

  // Add or update opportunity
  const handleSaveOpportunity = (savedOpp) => {
    const existingIndex = opportunities.findIndex(o => o.id === savedOpp.id);
    let updated;
    if (existingIndex >= 0) {
      updated = [...opportunities];
      updated[existingIndex] = savedOpp;
    } else {
      updated = [savedOpp, ...opportunities];
    }

    setOpportunities(updated);
    try {
      localStorage.setItem(STORAGE_KEYS.OPPORTUNITIES, JSON.stringify(updated));
      localStorage.setItem(STORAGE_KEYS.SELECTED_OPP_ID, savedOpp.id);
    } catch (e) {
      console.error("Failed to save opportunities to localStorage", e);
    }
    setSelectedOppId(savedOpp.id);
    setOpportunityToEdit(null);
    setIsCustomModalOpen(false);
    setActiveTab('checker');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Reset all application data
  const handleResetAllData = () => {
    if (window.confirm("Are you sure you want to reset all data and revert to initial sample opportunities?")) {
      try {
        localStorage.removeItem(STORAGE_KEYS.PROFILE);
        localStorage.removeItem(STORAGE_KEYS.OPPORTUNITIES);
        localStorage.removeItem(STORAGE_KEYS.SELECTED_OPP_ID);
      } catch (e) {
        console.error(e);
      }
      setProfile(SAMPLE_STUDENT_PROFILES[0].profile);
      setOpportunities(SAMPLE_OPPORTUNITIES);
      setSelectedOppId(SAMPLE_OPPORTUNITIES[0]?.id || null);
      setActiveTab('explore');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedOpp={selectedOpportunity}
        onNewCustomOpp={() => handleOpenCustomModal(null)}
        profileCompleteness={profileCompleteness}
      />

      {/* Student End-to-End Workflow Breadcrumb */}
      {activeTab !== 'colleges' && (
        <StudentJourneyBanner
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          selectedOpp={selectedOpportunity}
          profileCompleteness={profileCompleteness}
          readinessPercentage={evaluationReport?.summary?.readinessPercentage}
        />
      )}

      {/* Main View Area */}
      <main className="flex-1">
        
        {activeTab === 'explore' && (
          <OpportunityList
            opportunities={opportunities}
            selectedOpp={selectedOpportunity}
            onSelectForCheck={handleSelectOpportunity}
            onViewDetails={(opp) => setViewingOppDetails(opp)}
            onOpenCustomModal={() => handleOpenCustomModal(null)}
            onEditOpportunity={(opp) => handleOpenCustomModal(opp)}
          />
        )}

        {activeTab === 'profile' && (
          <StudentProfileForm
            profile={profile}
            selectedOpp={selectedOpportunity}
            opportunities={opportunities}
            onSaveProfile={handleSaveProfile}
            onProceedToChecker={() => {
              if (selectedOpportunity) {
                setActiveTab('checker');
              } else {
                setActiveTab('explore');
              }
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'checker' && (
          <EligibilityResults
            report={evaluationReport}
            opportunity={selectedOpportunity}
            profile={profile}
            onUpdateCustomResponse={handleUpdateCustomResponse}
            onEditOpportunity={(opp) => handleOpenCustomModal(opp)}
            onEditProfile={() => {
              setActiveTab('profile');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onBackToOpportunities={() => {
              setActiveTab('explore');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'colleges' && (
          <ForColleges 
            onBackToStudentFlow={() => {
              setActiveTab('explore');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

      </main>

      {/* Footer */}
      <Footer
        onResetAllData={handleResetAllData}
        setActiveTab={setActiveTab}
      />

      {/* Detail Modal */}
      {viewingOppDetails && (
        <OpportunityModal
          opportunity={viewingOppDetails}
          onClose={() => setViewingOppDetails(null)}
          onCheckEligibility={(opp) => handleSelectOpportunity(opp)}
          onEditOpportunity={(opp) => handleOpenCustomModal(opp)}
        />
      )}

      {/* Custom Opportunity Creation & Editing Modal */}
      {isCustomModalOpen && (
        <CustomOpportunityModal
          isOpen={isCustomModalOpen}
          opportunityToEdit={opportunityToEdit}
          onClose={() => {
            setIsCustomModalOpen(false);
            setOpportunityToEdit(null);
          }}
          onSaveOpportunity={handleSaveOpportunity}
        />
      )}

    </div>
  );
}
