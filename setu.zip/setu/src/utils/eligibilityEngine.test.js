import { evaluateEligibility, STATUS_TYPES } from './eligibilityEngine.js';

function runTests() {
  console.log("=== RUNNING ELIGIBILITY ENGINE TESTS ===");
  let passed = 0;
  let total = 0;

  function assert(condition, testName) {
    total++;
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName}`);
    }
  }

  // Sample test opportunity
  const mockOpp = {
    id: "test-opp-1",
    category: "Internships",
    title: "Software Engineering Intern",
    organization: "Tech Corp",
    criteria: {
      allowedYears: ["3rd Year", "4th Year"],
      allowedBranches: ["Computer Science & Engineering (CSE)"],
      minCgpa: 8.0,
      requiredSkills: ["React", "Python"],
      requiredDocuments: ["Updated Resume / CV"],
      requiresGithub: true,
      maxFamilyIncomeLpa: null,
      minTeamSize: null,
      maxTeamSize: null
    }
  };

  // Test 1: Full Match Profile
  const fullMatchProfile = {
    fullName: "Test Student",
    yearOfStudy: "3rd Year",
    branch: "Computer Science & Engineering (CSE)",
    cgpa: "8.5",
    skills: ["React", "Python", "Git & GitHub"],
    documents: ["Updated Resume / CV", "College ID Card"],
    githubUrl: "https://github.com/test",
    portfolioUrl: "",
    familyIncomeLpa: "",
    teamSize: ""
  };

  const report1 = evaluateEligibility(fullMatchProfile, mockOpp);
  assert(report1.summary.verdictStatus === "FULLY_MATCHED", "Test 1.1: Full match verdict");
  assert(report1.summary.readinessPercentage === 100, "Test 1.2: Readiness is 100%");
  assert(report1.summary.mismatchedCount === 0, "Test 1.3: 0 mismatches");
  assert(report1.summary.missingCount === 0, "Test 1.4: 0 missing info");
  assert(report1.actionItems.length === 0, "Test 1.5: No action items needed");

  // Test 2: Incomplete profile (missing CGPA and GitHub) - MUST BE MISSING_INFO, NOT FAILURE
  const incompleteProfile = {
    fullName: "Incomplete Student",
    yearOfStudy: "3rd Year",
    branch: "Computer Science & Engineering (CSE)",
    cgpa: "", // Empty CGPA
    skills: ["React", "Python"],
    documents: ["Updated Resume / CV"],
    githubUrl: "", // Empty GitHub
    portfolioUrl: "",
    familyIncomeLpa: "",
    teamSize: ""
  };

  const report2 = evaluateEligibility(incompleteProfile, mockOpp);
  const cgpaItem = report2.items.find(i => i.id === "req_cgpa");
  const githubItem = report2.items.find(i => i.id === "req_github");

  assert(cgpaItem.status === STATUS_TYPES.MISSING_INFO, "Test 2.1: Empty CGPA results in MISSING_INFO");
  assert(githubItem.status === STATUS_TYPES.MISSING_INFO, "Test 2.2: Missing GitHub results in MISSING_INFO");
  assert(report2.summary.mismatchedCount === 0, "Test 2.3: Incomplete data is NEVER treated as MISMATCH failure");
  assert(report2.summary.missingCount === 2, "Test 2.4: Exactly 2 missing info items");
  assert(report2.summary.verdictStatus === "CONDITIONALLY_ELIGIBLE", "Test 2.5: Conditionally eligible verdict");

  // Test 3: Actual Mismatch (CGPA 7.2 < 8.0, 2nd Year instead of 3rd/4th)
  const mismatchProfile = {
    fullName: "Mismatch Student",
    yearOfStudy: "2nd Year",
    branch: "Computer Science & Engineering (CSE)",
    cgpa: "7.2",
    skills: ["React"], // missing Python
    documents: ["Updated Resume / CV"],
    githubUrl: "https://github.com/test",
    portfolioUrl: "",
    familyIncomeLpa: "",
    teamSize: ""
  };

  const report3 = evaluateEligibility(mismatchProfile, mockOpp);
  const yearItem = report3.items.find(i => i.id === "req_year");
  const cgpaItem3 = report3.items.find(i => i.id === "req_cgpa");
  const skillsItem3 = report3.items.find(i => i.id === "req_skills");

  assert(yearItem.status === STATUS_TYPES.MISMATCH, "Test 3.1: 2nd Year is MISMATCH when 3rd/4th required");
  assert(cgpaItem3.status === STATUS_TYPES.MISMATCH, "Test 3.2: 7.2 CGPA is MISMATCH against 8.0 cutoff");
  assert(skillsItem3.status === STATUS_TYPES.MISMATCH, "Test 3.3: Missing required skill Python is MISMATCH");
  assert(report3.actionItems.length > 0, "Test 3.4: Action items generated for mismatches");

  // Test 4: Scholarship Income Limits
  const mockScholarship = {
    id: "test-schol",
    category: "Scholarships",
    title: "Merit Grant",
    criteria: {
      allowedYears: ["1st Year", "2nd Year"],
      allowedBranches: ["Any"],
      minCgpa: 7.0,
      maxFamilyIncomeLpa: 5.0,
      requiredSkills: [],
      requiredDocuments: ["Annual Family Income Certificate"],
      requiresGithub: false
    }
  };

  const highIncomeProfile = {
    yearOfStudy: "1st Year",
    branch: "Mechanical Engineering (ME)",
    cgpa: "8.0",
    familyIncomeLpa: "8.5", // exceeds 5.0
    documents: ["Annual Family Income Certificate"]
  };

  const report4 = evaluateEligibility(highIncomeProfile, mockScholarship);
  const incomeItem = report4.items.find(i => i.id === "req_income");
  assert(incomeItem.status === STATUS_TYPES.MISMATCH, "Test 4.1: ₹8.5 LPA exceeds ₹5.0 LPA ceiling (MISMATCH)");

  // Test 5: Competition Team Size Limits
  const mockCompetition = {
    id: "test-comp",
    category: "Competitions",
    title: "Hackathon",
    criteria: {
      allowedYears: ["1st Year", "2nd Year", "3rd Year"],
      allowedBranches: ["Any"],
      minTeamSize: 3,
      maxTeamSize: 4
    }
  };

  const soloProfile = {
    yearOfStudy: "2nd Year",
    branch: "Computer Science & Engineering (CSE)",
    teamSize: "1" // below minTeamSize 3
  };

  const report5 = evaluateEligibility(soloProfile, mockCompetition);
  const teamItem = report5.items.find(i => i.id === "req_team");
  assert(teamItem.status === STATUS_TYPES.MISMATCH, "Test 5.1: Team size 1 below min 3 (MISMATCH)");

  // Test 6: Dynamic Custom Requirements (Number, Text, Skill, Document, Yes/No)
  const oppWithCustomReqs = {
    id: "test-custom-opp",
    category: "Internships",
    title: "Special Research Fellow",
    criteria: {
      allowedYears: ["3rd Year", "4th Year"],
      allowedBranches: ["Any"],
      customRequirements: [
        {
          id: "req_num_exp",
          name: "Prior Project Duration (Months)",
          type: "Number",
          operator: ">=",
          value: 3,
          explanation: "At least 3 months project duration required."
        },
        {
          id: "req_text_state",
          name: "State Domicile",
          type: "Text",
          operator: "contains",
          value: "Karnataka"
        },
        {
          id: "req_yesno_passport",
          name: "Has Valid Passport",
          type: "Yes/No",
          value: "Yes"
        },
        {
          id: "req_custom_skill",
          name: "Special Skill: Docker",
          type: "Skill",
          value: "Docker"
        },
        {
          id: "req_custom_doc",
          name: "NOC from Dean",
          type: "Document",
          value: "No Objection Certificate"
        }
      ]
    }
  };

  // Test 6.1: Profile with all questions UNANSWERED -> all custom requirements must be MISSING_INFO, NEVER automatic rejection
  const unansweredStudent = {
    yearOfStudy: "3rd Year",
    skills: ["Python"],
    documents: ["College ID Card"],
    customResponses: {}
  };

  const report6_1 = evaluateEligibility(unansweredStudent, oppWithCustomReqs);
  const customItems6_1 = report6_1.items.filter(i => i.category === "Custom Requirement");
  assert(customItems6_1.length === 5, "Test 6.1: All 5 custom requirements evaluated");
  assert(customItems6_1.every(i => i.status === STATUS_TYPES.MISSING_INFO || i.status === STATUS_TYPES.MISMATCH), "Test 6.2: Custom requirements evaluated without crash");
  const numItem = customItems6_1.find(i => i.id === "req_num_exp");
  const yesnoItem = customItems6_1.find(i => i.id === "req_yesno_passport");
  assert(numItem.status === STATUS_TYPES.MISSING_INFO, "Test 6.3: Unanswered number requirement is MISSING_INFO");
  assert(yesnoItem.status === STATUS_TYPES.MISSING_INFO, "Test 6.4: Unanswered Yes/No requirement is MISSING_INFO");
  assert(report6_1.summary.mismatchedCount <= 2, "Test 6.5: Missing questions are not counted as mismatches");

  // Test 6.2: Profile with full matches
  const matchingStudent = {
    yearOfStudy: "3rd Year",
    skills: ["Python", "Docker"],
    documents: ["College ID Card", "No Objection Certificate"],
    customResponses: {
      "req_num_exp": 5, // 5 >= 3 -> MATCH
      "req_text_state": "Karnataka State Resident", // contains "Karnataka" -> MATCH
      "req_yesno_passport": "Yes" // matches "Yes" -> MATCH
    }
  };

  const report6_2 = evaluateEligibility(matchingStudent, oppWithCustomReqs);
  const customItems6_2 = report6_2.items.filter(i => i.category === "Custom Requirement");
  assert(customItems6_2.every(i => i.status === STATUS_TYPES.MATCH), "Test 6.6: All custom requirements MATCH when satisfied");
  assert(report6_2.summary.readinessPercentage === 100, "Test 6.7: 100% readiness with custom requirements");

  // Test 6.3: Profile with mismatched custom values
  const mismatchStudent = {
    yearOfStudy: "3rd Year",
    skills: ["Python"], // missing Docker
    documents: ["College ID Card"], // missing NOC
    customResponses: {
      "req_num_exp": 1, // 1 < 3 -> MISMATCH
      "req_text_state": "Delhi", // does not contain Karnataka -> MISMATCH
      "req_yesno_passport": "No" // No != Yes -> MISMATCH
    }
  };

  const report6_3 = evaluateEligibility(mismatchStudent, oppWithCustomReqs);
  const numMismatch = report6_3.items.find(i => i.id === "req_num_exp");
  const textMismatch = report6_3.items.find(i => i.id === "req_text_state");
  const yesnoMismatch = report6_3.items.find(i => i.id === "req_yesno_passport");
  assert(numMismatch.status === STATUS_TYPES.MISMATCH, "Test 6.8: Numeric < cutoff is MISMATCH");
  assert(textMismatch.status === STATUS_TYPES.MISMATCH, "Test 6.9: Text mismatch is MISMATCH");
  assert(yesnoMismatch.status === STATUS_TYPES.MISMATCH, "Test 6.10: Yes/No mismatch is MISMATCH");
  assert(report6_3.actionItems.length >= 3, "Test 6.11: Custom mismatches dynamically generate action checklist items");

  console.log(`\n=============================`);
  console.log(`TOTAL TESTS: ${total} | PASSED: ${passed} | FAILED: ${total - passed}`);
  console.log(`=============================\n`);

  if (passed === total) {
    console.log("🎉 ALL TESTS PASSED SUCCESSFULLY!");
  } else {
    process.exit(1);
  }
}

runTests();
