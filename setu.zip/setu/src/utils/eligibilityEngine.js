/**
 * Smart Eligibility Checker Engine for OpportunityKit
 * Evaluates student profiles against opportunity requirements using pure rule-based logic.
 * Produces MATCH, MISMATCH, and MISSING_INFO statuses with clear natural-language explanations.
 */

export const STATUS_TYPES = {
  MATCH: "MATCH",
  MISMATCH: "MISMATCH",
  MISSING_INFO: "MISSING_INFO"
};

/**
 * Checks eligibility of a student profile against an opportunity's criteria.
 * @param {Object} profile - Student profile data
 * @param {Object} opportunity - Opportunity object containing criteria
 * @returns {Object} Full evaluation report with items, summary, readiness, and action items
 */
export function evaluateEligibility(profile, opportunity) {
  if (!profile || !opportunity || !opportunity.criteria) {
    return null;
  }

  const { criteria } = opportunity;
  const items = [];
  const actionItems = [];

  // 1. ACADEMIC YEAR CHECK
  if (criteria.allowedYears && criteria.allowedYears.length > 0) {
    const studentYear = (profile.yearOfStudy || "").trim();
    if (!studentYear) {
      items.push({
        id: "req_year",
        category: "Academic",
        label: "Eligible Year of Study",
        expected: criteria.allowedYears.join(", "),
        studentValue: "Not specified in profile",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: `This opportunity is intended for ${criteria.allowedYears.join(" or ")}. Please specify your year of study in your profile.`,
        isCritical: true
      });
      actionItems.push({
        id: "act_year",
        type: "missing_info",
        title: "Update Year of Study",
        description: "Specify your current academic year (e.g., 2nd Year, 3rd Year) in your profile.",
        completed: false
      });
    } else {
      const isMatch = criteria.allowedYears.some(
        y => y.toLowerCase() === studentYear.toLowerCase()
      );
      if (isMatch) {
        items.push({
          id: "req_year",
          category: "Academic",
          label: "Eligible Year of Study",
          expected: criteria.allowedYears.join(", "),
          studentValue: studentYear,
          status: STATUS_TYPES.MATCH,
          explanation: `Your current level (${studentYear}) matches the eligible cohort (${criteria.allowedYears.join(", ")}).`,
          isCritical: true
        });
      } else {
        items.push({
          id: "req_year",
          category: "Academic",
          label: "Eligible Year of Study",
          expected: criteria.allowedYears.join(", "),
          studentValue: studentYear,
          status: STATUS_TYPES.MISMATCH,
          explanation: `Opportunity requires ${criteria.allowedYears.join(", ")}, but your profile lists ${studentYear}.`,
          isCritical: true
        });
        actionItems.push({
          id: "act_year_mismatch",
          type: "critical_gap",
          title: "Cohort Discrepancy",
          description: `You are in ${studentYear}. Bookmark this opportunity for when you reach the eligible year, or verify if an exception is permitted.`,
          completed: false
        });
      }
    }
  }

  // 2. BRANCH / STREAM CHECK
  if (criteria.allowedBranches && criteria.allowedBranches.length > 0) {
    const allowsAny = criteria.allowedBranches.includes("Any");
    const studentBranch = (profile.branch || "").trim();

    if (allowsAny) {
      items.push({
        id: "req_branch",
        category: "Academic",
        label: "Eligible Degree / Branch",
        expected: "Open to All Disciplines (Any Branch)",
        studentValue: studentBranch || "Any (Not specified)",
        status: STATUS_TYPES.MATCH,
        explanation: "Open to students from all engineering and academic disciplines.",
        isCritical: false
      });
    } else if (!studentBranch) {
      items.push({
        id: "req_branch",
        category: "Academic",
        label: "Eligible Degree / Branch",
        expected: criteria.allowedBranches.join(", "),
        studentValue: "Not specified in profile",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: "Restricted to specific academic branches. Please add your engineering branch to confirm.",
        isCritical: true
      });
      actionItems.push({
        id: "act_branch",
        type: "missing_info",
        title: "Select Your Branch",
        description: "Specify your department/branch in your profile to verify branch eligibility.",
        completed: false
      });
    } else {
      const isMatch = criteria.allowedBranches.some(b =>
        b.toLowerCase().includes(studentBranch.toLowerCase()) ||
        studentBranch.toLowerCase().includes(b.toLowerCase())
      );

      if (isMatch) {
        items.push({
          id: "req_branch",
          category: "Academic",
          label: "Eligible Degree / Branch",
          expected: criteria.allowedBranches.join(", "),
          studentValue: studentBranch,
          status: STATUS_TYPES.MATCH,
          explanation: `Your branch (${studentBranch}) qualifies for this opportunity.`,
          isCritical: true
        });
      } else {
        items.push({
          id: "req_branch",
          category: "Academic",
          label: "Eligible Degree / Branch",
          expected: criteria.allowedBranches.join(", "),
          studentValue: studentBranch,
          status: STATUS_TYPES.MISMATCH,
          explanation: `Targeted exclusively for: ${criteria.allowedBranches.join(", ")}. Your branch is ${studentBranch}.`,
          isCritical: true
        });
        actionItems.push({
          id: "act_branch_mismatch",
          type: "critical_gap",
          title: "Branch Requirement",
          description: `This opportunity prioritizes ${criteria.allowedBranches.join(", ")}. Check if interdisciplinary applications are accepted.`,
          completed: false
        });
      }
    }
  }

  // 3. MINIMUM CGPA CHECK
  if (criteria.minCgpa !== null && criteria.minCgpa !== undefined) {
    const rawCgpa = profile.cgpa;
    const studentCgpa = rawCgpa !== "" && rawCgpa !== null && !isNaN(Number(rawCgpa))
      ? Number(rawCgpa)
      : null;

    if (studentCgpa === null) {
      items.push({
        id: "req_cgpa",
        category: "Academic",
        label: "Minimum CGPA / Percentage",
        expected: `≥ ${criteria.minCgpa.toFixed(1)} CGPA`,
        studentValue: "Not provided",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: `Minimum cutoff is ${criteria.minCgpa.toFixed(1)} CGPA. Please input your latest cumulative GPA.`,
        isCritical: true
      });
      actionItems.push({
        id: "act_cgpa",
        type: "missing_info",
        title: "Enter Cumulative CGPA",
        description: `Add your latest CGPA to your profile to verify you meet the ${criteria.minCgpa.toFixed(1)} cutoff.`,
        completed: false
      });
    } else if (studentCgpa >= criteria.minCgpa) {
      items.push({
        id: "req_cgpa",
        category: "Academic",
        label: "Minimum CGPA / Percentage",
        expected: `≥ ${criteria.minCgpa.toFixed(1)} CGPA`,
        studentValue: `${studentCgpa.toFixed(2)} CGPA`,
        status: STATUS_TYPES.MATCH,
        explanation: `Your CGPA (${studentCgpa.toFixed(2)}) meets and exceeds the cutoff requirement of ${criteria.minCgpa.toFixed(1)}.`,
        isCritical: true
      });
    } else {
      const gap = (criteria.minCgpa - studentCgpa).toFixed(2);
      items.push({
        id: "req_cgpa",
        category: "Academic",
        label: "Minimum CGPA / Percentage",
        expected: `≥ ${criteria.minCgpa.toFixed(1)} CGPA`,
        studentValue: `${studentCgpa.toFixed(2)} CGPA`,
        status: STATUS_TYPES.MISMATCH,
        explanation: `Your CGPA (${studentCgpa.toFixed(2)}) is below the required cutoff of ${criteria.minCgpa.toFixed(1)} (gap of ${gap}).`,
        isCritical: true
      });
      actionItems.push({
        id: "act_cgpa_gap",
        type: "critical_gap",
        title: `Academic Cutoff Shortfall (${gap} CGPA)`,
        description: `Current CGPA is ${studentCgpa.toFixed(2)}, but ${criteria.minCgpa.toFixed(1)} is required. Aim to elevate in the upcoming semester exams.`,
        completed: false
      });
    }
  }

  // 4. REQUIRED SKILLS CHECK
  if (criteria.requiredSkills && criteria.requiredSkills.length > 0) {
    const studentSkills = Array.isArray(profile.skills) ? profile.skills : [];
    
    if (studentSkills.length === 0) {
      items.push({
        id: "req_skills",
        category: "Competency",
        label: "Required Technical Skills",
        expected: criteria.requiredSkills.join(", "),
        studentValue: "No skills listed yet",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: `Requires proficiency in ${criteria.requiredSkills.join(", ")}. No technical skills have been added to your profile yet.`,
        isCritical: false
      });
      actionItems.push({
        id: "act_skills_empty",
        type: "missing_info",
        title: "Add Skills to Profile",
        description: `Add relevant skills such as ${criteria.requiredSkills.slice(0, 3).join(", ")} to your profile.`,
        completed: false
      });
    } else {
      // Find matching and missing skills
      const studentSkillsLower = studentSkills.map(s => s.toLowerCase().trim());
      const matchedSkills = [];
      const missingSkills = [];

      criteria.requiredSkills.forEach(req => {
        const found = studentSkillsLower.some(
          s => s === req.toLowerCase() || s.includes(req.toLowerCase()) || req.toLowerCase().includes(s)
        );
        if (found) {
          matchedSkills.push(req);
        } else {
          missingSkills.push(req);
        }
      });

      if (missingSkills.length === 0) {
        items.push({
          id: "req_skills",
          category: "Competency",
          label: "Required Technical Skills",
          expected: criteria.requiredSkills.join(", "),
          studentValue: matchedSkills.join(", "),
          status: STATUS_TYPES.MATCH,
          explanation: `You possess all ${criteria.requiredSkills.length} required skill(s): ${matchedSkills.join(", ")}.`,
          isCritical: false
        });
      } else if (matchedSkills.length > 0) {
        items.push({
          id: "req_skills",
          category: "Competency",
          label: "Required Technical Skills",
          expected: criteria.requiredSkills.join(", "),
          studentValue: `Matched (${matchedSkills.join(", ")}), Missing (${missingSkills.join(", ")})`,
          status: STATUS_TYPES.MISMATCH,
          explanation: `Partially matched. You have ${matchedSkills.join(", ")}, but still need: ${missingSkills.join(", ")}.`,
          isCritical: false
        });
        missingSkills.forEach(skill => {
          actionItems.push({
            id: `act_skill_${skill.toLowerCase().replace(/[^a-z0-9]/g, "_")}`,
            type: "critical_gap",
            title: `Learn & Demonstrate Skill: ${skill}`,
            description: `Study ${skill} fundamentals or build a mini-project showcasing it, then add it to your profile.`,
            completed: false
          });
        });
      } else {
        items.push({
          id: "req_skills",
          category: "Competency",
          label: "Required Technical Skills",
          expected: criteria.requiredSkills.join(", "),
          studentValue: studentSkills.join(", "),
          status: STATUS_TYPES.MISMATCH,
          explanation: `None of the required skills (${criteria.requiredSkills.join(", ")}) match your listed skills.`,
          isCritical: false
        });
        missingSkills.forEach(skill => {
          actionItems.push({
            id: `act_skill_${skill.toLowerCase().replace(/[^a-z0-9]/g, "_")}`,
            type: "critical_gap",
            title: `Acquire Prerequisite: ${skill}`,
            description: `This opportunity requires demonstrated ability in ${skill}. Plan learning resources and coursework.`,
            completed: false
          });
        });
      }
    }
  }

  // 5. REQUIRED DOCUMENTS CHECK
  if (criteria.requiredDocuments && criteria.requiredDocuments.length > 0) {
    const studentDocs = Array.isArray(profile.documents) ? profile.documents : [];
    
    if (studentDocs.length === 0) {
      items.push({
        id: "req_documents",
        category: "Verification",
        label: "Required Documents",
        expected: criteria.requiredDocuments.join("; "),
        studentValue: "No documents listed as ready",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: `Requires: ${criteria.requiredDocuments.join(", ")}. Please mark which documents you currently have prepared.`,
        isCritical: false
      });
      actionItems.push({
        id: "act_docs_empty",
        type: "document",
        title: "Prepare Required Documents",
        description: `Check off verified documents in your profile: ${criteria.requiredDocuments.join(", ")}.`,
        completed: false
      });
    } else {
      const studentDocsLower = studentDocs.map(d => d.toLowerCase().trim());
      const missingDocs = criteria.requiredDocuments.filter(
        reqDoc => !studentDocsLower.some(d => d.includes(reqDoc.toLowerCase()) || reqDoc.toLowerCase().includes(d))
      );
      const matchedDocs = criteria.requiredDocuments.filter(
        reqDoc => studentDocsLower.some(d => d.includes(reqDoc.toLowerCase()) || reqDoc.toLowerCase().includes(d))
      );

      if (missingDocs.length === 0) {
        items.push({
          id: "req_documents",
          category: "Verification",
          label: "Required Documents",
          expected: criteria.requiredDocuments.join(", "),
          studentValue: matchedDocs.join(", "),
          status: STATUS_TYPES.MATCH,
          explanation: `All ${criteria.requiredDocuments.length} required verification documents are ready in your profile.`,
          isCritical: false
        });
      } else {
        items.push({
          id: "req_documents",
          category: "Verification",
          label: "Required Documents",
          expected: criteria.requiredDocuments.join(", "),
          studentValue: `Ready: ${matchedDocs.length > 0 ? matchedDocs.join(", ") : "None"}; Missing: ${missingDocs.join(", ")}`,
          status: STATUS_TYPES.MISMATCH,
          explanation: `Missing ${missingDocs.length} verification document(s): ${missingDocs.join(", ")}.`,
          isCritical: false
        });
        missingDocs.forEach(doc => {
          actionItems.push({
            id: `act_doc_${doc.toLowerCase().replace(/[^a-z0-9]/g, "_")}`,
            type: "document",
            title: `Prepare: ${doc}`,
            description: `Arrange, scan, and confirm this official document (${doc}) before submitting your application.`,
            completed: false
          });
        });
      }
    }
  }

  // 6. GITHUB / PORTFOLIO REQUIREMENT
  if (criteria.requiresGithub) {
    const hasGithub = Boolean(profile.githubUrl && profile.githubUrl.trim().length > 3);
    const hasPortfolio = Boolean(profile.portfolioUrl && profile.portfolioUrl.trim().length > 3);

    if (hasGithub || hasPortfolio) {
      items.push({
        id: "req_github",
        category: "Portfolio",
        label: "Public Code Repository / Portfolio",
        expected: "Active GitHub or Project Portfolio URL",
        studentValue: profile.githubUrl || profile.portfolioUrl,
        status: STATUS_TYPES.MATCH,
        explanation: "Repository / portfolio link is provided for technical verification.",
        isCritical: false
      });
    } else {
      items.push({
        id: "req_github",
        category: "Portfolio",
        label: "Public Code Repository / Portfolio",
        expected: "Active GitHub or Project Portfolio URL",
        studentValue: "Not provided in profile",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: "Evaluators inspect your code repositories or project demos. Please provide your GitHub or portfolio URL.",
        isCritical: false
      });
      actionItems.push({
        id: "act_github",
        type: "missing_info",
        title: "Add GitHub / Portfolio Link",
        description: "Provide your GitHub profile URL or live portfolio website link so evaluators can inspect your code.",
        completed: false
      });
    }
  }

  // 7. MAXIMUM FAMILY INCOME (SCHOLARSHIPS)
  if (criteria.maxFamilyIncomeLpa !== null && criteria.maxFamilyIncomeLpa !== undefined) {
    const rawIncome = profile.familyIncomeLpa;
    const studentIncome = rawIncome !== "" && rawIncome !== null && !isNaN(Number(rawIncome))
      ? Number(rawIncome)
      : null;

    if (studentIncome === null) {
      items.push({
        id: "req_income",
        category: "Socio-Economic",
        label: "Annual Family Income Ceiling",
        expected: `≤ ₹${criteria.maxFamilyIncomeLpa.toFixed(1)} LPA`,
        studentValue: "Not declared in profile",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: `This scholarship requires an annual household income of at most ₹${criteria.maxFamilyIncomeLpa.toFixed(1)} LPA. Please declare family income in your profile.`,
        isCritical: true
      });
      actionItems.push({
        id: "act_income_missing",
        type: "missing_info",
        title: "Declare Annual Family Income",
        description: `This scholarship is income-dependent (≤ ₹${criteria.maxFamilyIncomeLpa} LPA). Update the family income field in your profile.`,
        completed: false
      });
    } else if (studentIncome <= criteria.maxFamilyIncomeLpa) {
      items.push({
        id: "req_income",
        category: "Socio-Economic",
        label: "Annual Family Income Ceiling",
        expected: `≤ ₹${criteria.maxFamilyIncomeLpa.toFixed(1)} LPA`,
        studentValue: `₹${studentIncome.toFixed(1)} LPA`,
        status: STATUS_TYPES.MATCH,
        explanation: `Family income (₹${studentIncome.toFixed(1)} LPA) complies with the eligible ceiling (₹${criteria.maxFamilyIncomeLpa.toFixed(1)} LPA).`,
        isCritical: true
      });
    } else {
      items.push({
        id: "req_income",
        category: "Socio-Economic",
        label: "Annual Family Income Ceiling",
        expected: `≤ ₹${criteria.maxFamilyIncomeLpa.toFixed(1)} LPA`,
        studentValue: `₹${studentIncome.toFixed(1)} LPA`,
        status: STATUS_TYPES.MISMATCH,
        explanation: `Declared annual income (₹${studentIncome.toFixed(1)} LPA) exceeds the grant limit of ₹${criteria.maxFamilyIncomeLpa.toFixed(1)} LPA.`,
        isCritical: true
      });
      actionItems.push({
        id: "act_income_mismatch",
        type: "critical_gap",
        title: "Income Ceiling Exceeded",
        description: `Declared income of ₹${studentIncome.toFixed(1)} LPA exceeds the cap. Consider merit-based scholarships without income caps instead.`,
        completed: false
      });
    }
  }

  // 8. TEAM SIZE (COMPETITIONS)
  if (criteria.minTeamSize !== null && criteria.minTeamSize !== undefined) {
    const rawTeam = profile.teamSize;
    const studentTeam = rawTeam !== "" && rawTeam !== null && !isNaN(Number(rawTeam))
      ? Number(rawTeam)
      : null;

    const expectedRange = criteria.minTeamSize === criteria.maxTeamSize
      ? `Exactly ${criteria.minTeamSize} members`
      : criteria.maxTeamSize
        ? `${criteria.minTeamSize} - ${criteria.maxTeamSize} members`
        : `Minimum ${criteria.minTeamSize} members`;

    if (studentTeam === null) {
      items.push({
        id: "req_team",
        category: "Format",
        label: "Required Team Size",
        expected: expectedRange,
        studentValue: "Not specified",
        status: STATUS_TYPES.MISSING_INFO,
        explanation: `Competition entry requires ${expectedRange}. Please indicate your current team size in your profile.`,
        isCritical: false
      });
      actionItems.push({
        id: "act_team_missing",
        type: "missing_info",
        title: "Confirm Team Size",
        description: `Set your team size in your profile to check compliance with the ${expectedRange} rule.`,
        completed: false
      });
    } else {
      const minValid = studentTeam >= criteria.minTeamSize;
      const maxValid = criteria.maxTeamSize ? studentTeam <= criteria.maxTeamSize : true;

      if (minValid && maxValid) {
        items.push({
          id: "req_team",
          category: "Format",
          label: "Required Team Size",
          expected: expectedRange,
          studentValue: `${studentTeam} member(s)`,
          status: STATUS_TYPES.MATCH,
          explanation: `Your team size of ${studentTeam} meets the team size criteria (${expectedRange}).`,
          isCritical: false
        });
      } else {
        items.push({
          id: "req_team",
          category: "Format",
          label: "Required Team Size",
          expected: expectedRange,
          studentValue: `${studentTeam} member(s)`,
          status: STATUS_TYPES.MISMATCH,
          explanation: `Your team size (${studentTeam}) does not fall within the required range of ${expectedRange}.`,
          isCritical: false
        });
        actionItems.push({
          id: "act_team_mismatch",
          type: "critical_gap",
          title: "Adjust Team Formation",
          description: `Assemble teammates or adjust roster to meet the required size: ${expectedRange}.`,
          completed: false
        });
      }
    }
  }

  // 9. DYNAMIC CUSTOM REQUIREMENTS EVALUATION
  if (Array.isArray(criteria.customRequirements) && criteria.customRequirements.length > 0) {
    criteria.customRequirements.forEach((req, idx) => {
      if (!req || !req.name) return;

      const reqId = req.id || `custom_req_${idx}`;
      const customResponses = profile.customResponses || {};
      // Lookup response by ID first, then by name
      const rawAns = customResponses[reqId] !== undefined ? customResponses[reqId] : customResponses[req.name];
      const isUnanswered = rawAns === undefined || rawAns === null || String(rawAns).trim() === "";

      const reqType = (req.type || "Text").trim();
      const operator = req.operator || (reqType === "Number" ? ">=" : reqType === "Text" ? "contains" : "==");

      let expectedDisplay = "";
      let studentDisplay = isUnanswered ? "Not answered yet" : String(rawAns);
      let status = STATUS_TYPES.MISSING_INFO;
      let explanation = "";

      switch (reqType) {
        case "Number": {
          const targetNum = Number(req.value);
          const opSymbol = operator === "<=" ? "≤" : operator === "==" ? "=" : "≥";
          expectedDisplay = `${opSymbol} ${targetNum}`;

          if (isUnanswered) {
            status = STATUS_TYPES.MISSING_INFO;
            explanation = req.explanation 
              ? `${req.explanation} Please specify your numerical value in your profile.`
              : `Requires numeric value ${expectedDisplay}. Clarification needed to evaluate eligibility without guessing.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "missing_info",
              title: `Answer: ${req.name}`,
              description: `Provide your numeric answer for "${req.name}" (Required: ${expectedDisplay}).`,
              completed: false,
              reqId
            });
          } else {
            const studentNum = Number(rawAns);
            if (isNaN(studentNum)) {
              status = STATUS_TYPES.MISSING_INFO;
              studentDisplay = `${rawAns} (Invalid number)`;
              explanation = `The value provided ("${rawAns}") is not a valid number. Please provide clarification.`;
              actionItems.push({
                id: `act_${reqId}`,
                type: "missing_info",
                title: `Clarify: ${req.name}`,
                description: `Enter a valid number for "${req.name}".`,
                completed: false,
                reqId
              });
            } else {
              studentDisplay = `${studentNum}`;
              let isMatch = false;
              if (operator === "<=") {
                isMatch = studentNum <= targetNum;
              } else if (operator === "==") {
                isMatch = studentNum === targetNum;
              } else {
                isMatch = studentNum >= targetNum;
              }

              if (isMatch) {
                status = STATUS_TYPES.MATCH;
                explanation = req.explanation
                  ? `${req.explanation} (Your value ${studentNum} meets ${expectedDisplay}).`
                  : `Your value (${studentNum}) satisfies the required condition (${expectedDisplay}).`;
              } else {
                status = STATUS_TYPES.MISMATCH;
                explanation = req.explanation
                  ? `${req.explanation} (Your value ${studentNum} does not satisfy ${expectedDisplay}).`
                  : `Your value (${studentNum}) does not meet the required cutoff (${expectedDisplay}).`;
                actionItems.push({
                  id: `act_${reqId}`,
                  type: "critical_gap",
                  title: `Requirement Shortfall: ${req.name}`,
                  description: `Required: ${expectedDisplay}. Your current: ${studentNum}.`,
                  completed: false,
                  reqId
                });
              }
            }
          }
          break;
        }

        case "Text": {
          const targetText = String(req.value || "").trim();
          expectedDisplay = operator === "exact" ? `"${targetText}" (Exact)` : `Must contain "${targetText}"`;

          if (isUnanswered) {
            status = STATUS_TYPES.MISSING_INFO;
            explanation = req.explanation
              ? `${req.explanation} Please answer this requirement.`
              : `Requires "${targetText}". Please provide your answer in your profile.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "missing_info",
              title: `Answer: ${req.name}`,
              description: `Provide your response for "${req.name}" (Required: "${targetText}").`,
              completed: false,
              reqId
            });
          } else {
            const studentText = String(rawAns).trim();
            studentDisplay = `"${studentText}"`;
            let isMatch = false;

            if (operator === "exact") {
              isMatch = studentText.toLowerCase() === targetText.toLowerCase();
            } else {
              isMatch = studentText.toLowerCase().includes(targetText.toLowerCase()) || targetText.toLowerCase().includes(studentText.toLowerCase());
            }

            if (isMatch) {
              status = STATUS_TYPES.MATCH;
              explanation = req.explanation
                ? `${req.explanation} (Matched with your response).`
                : `Your response "${studentText}" satisfies the requirement.`;
            } else {
              status = STATUS_TYPES.MISMATCH;
              explanation = req.explanation
                ? `${req.explanation} (Your response "${studentText}" did not match).`
                : `Expected "${targetText}", but your answer is "${studentText}".`;
              actionItems.push({
                id: `act_${reqId}`,
                type: "critical_gap",
                title: `Mismatch: ${req.name}`,
                description: `Requirement specifies "${targetText}". Your response: "${studentText}".`,
                completed: false,
                reqId
              });
            }
          }
          break;
        }

        case "Skill": {
          const targetSkill = String(req.value || req.name).trim();
          expectedDisplay = `Proficiency in ${targetSkill}`;

          const studentSkillsLower = (profile.skills || []).map(s => s.toLowerCase().trim());
          const hasInSkillsList = studentSkillsLower.some(
            s => s === targetSkill.toLowerCase() || s.includes(targetSkill.toLowerCase()) || targetSkill.toLowerCase().includes(s)
          );
          const hasInCustom = !isUnanswered && (String(rawAns).toLowerCase() === "yes" || String(rawAns).toLowerCase().includes(targetSkill.toLowerCase()));

          if (hasInSkillsList || hasInCustom) {
            status = STATUS_TYPES.MATCH;
            studentDisplay = `Verified (${targetSkill})`;
            explanation = req.explanation
              ? `${req.explanation} (Skill verified in your profile).`
              : `Demonstrated proficiency in ${targetSkill}.`;
          } else if (isUnanswered && (!profile.skills || profile.skills.length === 0)) {
            status = STATUS_TYPES.MISSING_INFO;
            explanation = `Requires ${targetSkill}. Please confirm whether you have acquired this skill.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "missing_info",
              title: `Confirm Skill: ${targetSkill}`,
              description: `Confirm whether you possess ${targetSkill} in your profile skills.`,
              completed: false,
              reqId
            });
          } else {
            status = STATUS_TYPES.MISMATCH;
            studentDisplay = isUnanswered ? "Skill not listed" : String(rawAns);
            explanation = req.explanation
              ? `${req.explanation} (Skill not found in your profile).`
              : `The required skill "${targetSkill}" is not listed in your profile.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "critical_gap",
              title: `Acquire Skill: ${targetSkill}`,
              description: `Learn ${targetSkill} or add it to your profile skills list to meet this criteria.`,
              completed: false,
              reqId
            });
          }
          break;
        }

        case "Document": {
          const targetDoc = String(req.value || req.name).trim();
          expectedDisplay = `Prepared Document: ${targetDoc}`;

          const studentDocsLower = (profile.documents || []).map(d => d.toLowerCase().trim());
          const hasInDocList = studentDocsLower.some(
            d => d.includes(targetDoc.toLowerCase()) || targetDoc.toLowerCase().includes(d)
          );
          const hasInCustom = !isUnanswered && (String(rawAns).toLowerCase() === "yes" || String(rawAns).toLowerCase().includes(targetDoc.toLowerCase()));

          if (hasInDocList || hasInCustom) {
            status = STATUS_TYPES.MATCH;
            studentDisplay = `Ready (${targetDoc})`;
            explanation = req.explanation
              ? `${req.explanation} (Document verified as prepared).`
              : `Required document (${targetDoc}) is ready for submission.`;
          } else if (isUnanswered && (!profile.documents || profile.documents.length === 0)) {
            status = STATUS_TYPES.MISSING_INFO;
            explanation = `Mandatory document: ${targetDoc}. Please confirm if you have it ready.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "document",
              title: `Confirm Document: ${targetDoc}`,
              description: `Confirm whether "${targetDoc}" is prepared in your profile.`,
              completed: false,
              reqId
            });
          } else {
            status = STATUS_TYPES.MISMATCH;
            studentDisplay = isUnanswered ? "Document not ready" : String(rawAns);
            explanation = req.explanation
              ? `${req.explanation} (Document not ready).`
              : `Mandatory document "${targetDoc}" is missing from your profile paperwork checklist.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "document",
              title: `Prepare: ${targetDoc}`,
              description: `Arrange and obtain "${targetDoc}" for your application.`,
              completed: false,
              reqId
            });
          }
          break;
        }

        case "Yes/No":
        default: {
          const targetBool = String(req.value).toLowerCase() === "no" ? "No" : "Yes";
          expectedDisplay = `Must be ${targetBool}`;

          if (isUnanswered) {
            status = STATUS_TYPES.MISSING_INFO;
            explanation = req.explanation
              ? `${req.explanation} Please confirm (Yes or No).`
              : `Requires confirmation (${targetBool}). Please provide clarification instead of guessing.`;
            actionItems.push({
              id: `act_${reqId}`,
              type: "missing_info",
              title: `Confirm: ${req.name}`,
              description: `Answer Yes/No for "${req.name}" (Required: ${targetBool}).`,
              completed: false,
              reqId
            });
          } else {
            const studentNorm = String(rawAns).toLowerCase().trim();
            const studentAnsText = studentNorm === "yes" || studentNorm === "true" || studentNorm === "1" ? "Yes" : studentNorm === "no" || studentNorm === "false" || studentNorm === "0" ? "No" : rawAns;
            studentDisplay = studentAnsText;

            const isMatch = studentAnsText.toLowerCase() === targetBool.toLowerCase();

            if (isMatch) {
              status = STATUS_TYPES.MATCH;
              explanation = req.explanation
                ? `${req.explanation} (Requirement confirmed).`
                : `Condition confirmed: your answer (${studentAnsText}) satisfies the required condition (${targetBool}).`;
            } else {
              status = STATUS_TYPES.MISMATCH;
              explanation = req.explanation
                ? `${req.explanation} (Condition not met).`
                : `Requires ${targetBool}, but your answer is ${studentAnsText}.`;
              actionItems.push({
                id: `act_${reqId}`,
                type: "critical_gap",
                title: `Condition Unmet: ${req.name}`,
                description: `Required: ${targetBool}. Your answer: ${studentAnsText}.`,
                completed: false,
                reqId
              });
            }
          }
          break;
        }
      }

      items.push({
        id: reqId,
        category: "Custom Requirement",
        label: req.name,
        expected: expectedDisplay,
        studentValue: studentDisplay,
        status,
        explanation,
        isCritical: Boolean(req.isCritical),
        isCustom: true,
        customReq: req
      });
    });
  }

  // COMPUTE SUMMARY & READINESS PERCENTAGE
  const totalCount = items.length;
  const matchedCount = items.filter(i => i.status === STATUS_TYPES.MATCH).length;
  const mismatchedCount = items.filter(i => i.status === STATUS_TYPES.MISMATCH).length;
  const missingCount = items.filter(i => i.status === STATUS_TYPES.MISSING_INFO).length;

  const readinessPercentage = totalCount > 0 ? Math.round((matchedCount / totalCount) * 100) : 0;

  // OVERALL ELIGIBILITY VERDICT
  let verdictStatus = "Eligible";
  let verdictColor = "green"; // green, amber, red, blue
  let verdictTitle = "High Eligibility";
  let verdictDescription = "";

  if (mismatchedCount === 0 && missingCount === 0) {
    verdictStatus = "FULLY_MATCHED";
    verdictColor = "emerald";
    verdictTitle = "Strong Match — 100% Ready to Apply";
    verdictDescription = "Congratulations! Your profile satisfies all eligibility criteria and prerequisites for this opportunity.";
  } else if (mismatchedCount === 0 && missingCount > 0) {
    verdictStatus = "CONDITIONALLY_ELIGIBLE";
    verdictColor = "amber";
    verdictTitle = "Conditionally Eligible — Missing Profile Details";
    verdictDescription = `You have no known mismatches, but ${missingCount} requirement(s) need confirmation from your profile before you submit.`;
  } else if (mismatchedCount > 0 && readinessPercentage >= 50) {
    verdictStatus = "PARTIALLY_ELIGIBLE";
    verdictColor = "blue";
    verdictTitle = "Partially Eligible — Action Required";
    verdictDescription = `You meet ${matchedCount} out of ${totalCount} requirements. Address the gaps in the checklist below to boost your readiness.`;
  } else {
    verdictStatus = "LOW_MATCH";
    verdictColor = "rose";
    verdictTitle = "Eligibility Gaps Detected";
    verdictDescription = `Your profile currently misses ${mismatchedCount} core criteria. Review the mismatch explanations below or explore alternative opportunities.`;
  }

  return {
    items,
    summary: {
      totalCount,
      matchedCount,
      mismatchedCount,
      missingCount,
      readinessPercentage,
      verdictStatus,
      verdictColor,
      verdictTitle,
      verdictDescription
    },
    actionItems
  };
}
