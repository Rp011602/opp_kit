export const SAMPLE_OPPORTUNITIES = [
  // --- INTERNSHIPS ---
  {
    id: "opp-intern-1",
    category: "Internships",
    title: "Software Development Engineering (SDE) Intern",
    organization: "Amazon WOW 2026",
    badge: "Tech Internship",
    deadline: "2026-05-15",
    stipendOrPrize: "₹80,000 / month + Mentorship",
    location: "Bangalore / Hyderabad (Hybrid)",
    description: "Build scalable distributed services and gain hands-on production engineering experience with senior AWS & Retail tech mentors.",
    criteria: {
      allowedYears: ["2nd Year", "3rd Year"],
      allowedBranches: [
        "Computer Science & Engineering (CSE)",
        "Information Technology (IT)",
        "Electronics & Communication Engineering (ECE)",
        "Artificial Intelligence & Data Science (AI & DS)"
      ],
      minCgpa: 7.0,
      requiredSkills: ["Data Structures & Algorithms", "Python", "Java"],
      requiredDocuments: ["Updated Resume / CV", "College ID Card", "Semester Marksheets / Official Transcripts"],
      requiresGithub: true,
      maxFamilyIncomeLpa: null,
      minTeamSize: null,
      maxTeamSize: null
    }
  },
  {
    id: "opp-intern-2",
    category: "Internships",
    title: "Frontend Engineering Intern (React & UI)",
    organization: "Zerodha Tech / Rainmatter",
    badge: "FinTech Internship",
    deadline: "2026-04-30",
    stipendOrPrize: "₹55,000 / month",
    location: "Remote / Bengaluru",
    description: "Help build lightning-fast web applications, accessible design systems, and responsive trading interfaces for millions of users.",
    criteria: {
      allowedYears: ["2nd Year", "3rd Year", "4th Year"],
      allowedBranches: ["Any"],
      minCgpa: 6.5,
      requiredSkills: ["React", "JavaScript", "Tailwind CSS", "Git & GitHub"],
      requiredDocuments: ["Updated Resume / CV"],
      requiresGithub: true,
      maxFamilyIncomeLpa: null,
      minTeamSize: null,
      maxTeamSize: null
    }
  },
  {
    id: "opp-intern-3",
    category: "Internships",
    title: "Research & Space Applications Intern",
    organization: "ISRO SAC (Space Applications Centre)",
    badge: "Govt Research",
    deadline: "2026-06-10",
    stipendOrPrize: "Govt Stipend + Certification",
    location: "Ahmedabad, Gujarat",
    description: "Engage in research projects covering satellite data processing, telemetry signal decoding, or embedded payloads.",
    criteria: {
      allowedYears: ["3rd Year", "4th Year", "Postgraduate / Masters"],
      allowedBranches: [
        "Computer Science & Engineering (CSE)",
        "Electronics & Communication Engineering (ECE)",
        "Electrical & Electronics Engineering (EEE)"
      ],
      minCgpa: 8.0,
      requiredSkills: ["Python", "C++"],
      requiredDocuments: [
        "Updated Resume / CV",
        "College ID Card",
        "Semester Marksheets / Official Transcripts",
        "Bonafide Student Certificate",
        "Letter of Recommendation (LOR)"
      ],
      requiresGithub: false,
      maxFamilyIncomeLpa: null,
      minTeamSize: null,
      maxTeamSize: null,
      customRequirements: [
        {
          id: "isro_cust_citizenship",
          name: "Indian Citizenship / Resident Verification",
          type: "Yes/No",
          value: "Yes",
          explanation: "Mandatory for government security clearance at ISRO Space Applications Centre."
        },
        {
          id: "isro_cust_lab_exp",
          name: "Prior Lab / Project Duration (Months)",
          type: "Number",
          operator: ">=",
          value: 3,
          explanation: "Must have at least 3 months of verified laboratory or hardware project experience."
        }
      ]
    }
  },

  // --- SCHOLARSHIPS ---
  {
    id: "opp-schol-1",
    category: "Scholarships",
    title: "Reliance Foundation Undergraduate Scholarship 2026",
    organization: "Reliance Foundation",
    badge: "Merit-cum-Means",
    deadline: "2026-08-31",
    stipendOrPrize: "Up to ₹2,00,000 over degree duration",
    location: "Pan-India",
    description: "Empowering meritorious undergraduate students from economically challenged backgrounds across first-year degree programs.",
    criteria: {
      allowedYears: ["1st Year", "2nd Year"],
      allowedBranches: ["Any"],
      minCgpa: 7.5,
      requiredSkills: [],
      requiredDocuments: [
        "College ID Card",
        "Semester Marksheets / Official Transcripts",
        "Annual Family Income Certificate",
        "Bonafide Student Certificate",
        "Government Photo ID (Aadhaar / Passport)"
      ],
      requiresGithub: false,
      maxFamilyIncomeLpa: 6.0,
      minTeamSize: null,
      maxTeamSize: null
    }
  },
  {
    id: "opp-schol-2",
    category: "Scholarships",
    title: "Adobe India Women-in-Tech Scholarship",
    organization: "Adobe Research",
    badge: "Merit Grant & Mentorship",
    deadline: "2026-07-15",
    stipendOrPrize: "₹1,00,000 + Summer Internship Opportunity",
    location: "Noida / Bangalore",
    description: "Recognizing outstanding female engineering students demonstrating leadership, strong academic merit, and technical passion.",
    criteria: {
      allowedYears: ["3rd Year"],
      allowedBranches: [
        "Computer Science & Engineering (CSE)",
        "Information Technology (IT)",
        "Artificial Intelligence & Data Science (AI & DS)",
        "Electronics & Communication Engineering (ECE)"
      ],
      minCgpa: 8.5,
      requiredSkills: ["Data Structures & Algorithms", "Git & GitHub"],
      requiredDocuments: [
        "Updated Resume / CV",
        "College ID Card",
        "Semester Marksheets / Official Transcripts",
        "Letter of Recommendation (LOR)"
      ],
      requiresGithub: true,
      maxFamilyIncomeLpa: null,
      minTeamSize: null,
      maxTeamSize: null,
      customRequirements: [
        {
          id: "adobe_cust_gender",
          name: "Gender Eligibility",
          type: "Text",
          operator: "contains",
          value: "Female",
          explanation: "Scholarship initiative specifically designated for female engineering leaders."
        }
      ]
    }
  },
  {
    id: "opp-schol-3",
    category: "Scholarships",
    title: "National Means Higher Education Grant",
    organization: "Ministry of Education",
    badge: "Government Assistance",
    deadline: "2026-09-30",
    stipendOrPrize: "₹50,000 / year tuition subsidy",
    location: "All Recognized Institutions",
    description: "Financial assistance program for students belonging to low-income households with sustained academic performance.",
    criteria: {
      allowedYears: ["1st Year", "2nd Year", "3rd Year", "4th Year"],
      allowedBranches: ["Any"],
      minCgpa: 6.0,
      requiredSkills: [],
      requiredDocuments: [
        "College ID Card",
        "Semester Marksheets / Official Transcripts",
        "Annual Family Income Certificate"
      ],
      requiresGithub: false,
      maxFamilyIncomeLpa: 4.5,
      minTeamSize: null,
      maxTeamSize: null
    }
  },

  // --- COMPETITIONS ---
  {
    id: "opp-comp-1",
    category: "Competitions",
    title: "Smart India Hackathon (SIH) 2026 - Hardware & Software Edition",
    organization: "MoE Innovation Cell & AICTE",
    badge: "National Hackathon",
    deadline: "2026-05-20",
    stipendOrPrize: "₹1,00,000 per Problem Statement Prize",
    location: "Nodal Centers Across India",
    description: "World's biggest open innovation model challenging student minds to solve real-world problems faced by central ministries and industries.",
    criteria: {
      allowedYears: ["1st Year", "2nd Year", "3rd Year", "4th Year", "Postgraduate / Masters"],
      allowedBranches: ["Any"],
      minCgpa: null,
      requiredSkills: ["Git & GitHub"],
      requiredDocuments: ["College ID Card", "Bonafide Student Certificate"],
      requiresGithub: true,
      maxFamilyIncomeLpa: null,
      minTeamSize: 6,
      maxTeamSize: 6,
      customRequirements: [
        {
          id: "sih_cust_female_member",
          name: "Mandatory Female Teammate Inclusion",
          type: "Yes/No",
          value: "Yes",
          explanation: "Smart India Hackathon regulation requires at least one female teammate in the roster."
        }
      ]
    }
  },
  {
    id: "opp-comp-2",
    category: "Competitions",
    title: "SETU 2026 Hackathon (Forge Realm - PS-03)",
    organization: "SETU Innovation Council",
    badge: "Student Tech Arena",
    deadline: "2026-04-25",
    stipendOrPrize: "₹75,000 Prize Pool + Incubation",
    location: "Virtual & Grand Finale On-Campus",
    description: "Design innovative student enablement tools, explainable AI, and actionable workflow builders for future learners.",
    criteria: {
      allowedYears: ["1st Year", "2nd Year", "3rd Year", "4th Year"],
      allowedBranches: ["Any"],
      minCgpa: null,
      requiredSkills: ["React", "JavaScript", "Git & GitHub"],
      requiredDocuments: ["College ID Card"],
      requiresGithub: true,
      maxFamilyIncomeLpa: null,
      minTeamSize: 1,
      maxTeamSize: 4
    }
  },
  {
    id: "opp-comp-3",
    category: "Competitions",
    title: "Flipkart GRiD 6.0 Engineering Challenge",
    organization: "Flipkart Tech",
    badge: "Corporate Coding & AI",
    deadline: "2026-06-30",
    stipendOrPrize: "₹5,25,000 + PPI (Interview Opportunities)",
    location: "Online Rounds + Bangalore Finale",
    description: "Flagship engineering challenge testing students on complex algorithmic problems, machine learning pipelines, and robotics simulations.",
    criteria: {
      allowedYears: ["2nd Year", "3rd Year", "4th Year"],
      allowedBranches: [
        "Computer Science & Engineering (CSE)",
        "Information Technology (IT)",
        "Electronics & Communication Engineering (ECE)",
        "Electrical & Electronics Engineering (EEE)",
        "Artificial Intelligence & Data Science (AI & DS)"
      ],
      minCgpa: 7.0,
      requiredSkills: ["Data Structures & Algorithms", "Python"],
      requiredDocuments: ["College ID Card", "Updated Resume / CV"],
      requiresGithub: false,
      maxFamilyIncomeLpa: null,
      minTeamSize: 2,
      maxTeamSize: 3
    }
  }
];
