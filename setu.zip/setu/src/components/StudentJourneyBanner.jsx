import React from 'react';
import { Compass, UserCheck, CheckCircle2, ListTodo, ArrowRight } from 'lucide-react';

export default function StudentJourneyBanner({ 
  activeTab, 
  setActiveTab, 
  selectedOpp, 
  profileCompleteness, 
  readinessPercentage 
}) {
  const steps = [
    {
      id: 'explore',
      number: '1',
      title: 'Select Opportunity',
      desc: selectedOpp ? selectedOpp.title : 'Choose an internship or grant',
      icon: Compass,
      isDone: Boolean(selectedOpp),
      badge: selectedOpp ? 'Selected' : 'Required'
    },
    {
      id: 'profile',
      number: '2',
      title: 'Student Profile',
      desc: profileCompleteness > 0 ? `${profileCompleteness}% filled` : 'Add branch, CGPA & skills',
      icon: UserCheck,
      isDone: profileCompleteness >= 60,
      badge: `${profileCompleteness}% ready`
    },
    {
      id: 'checker',
      number: '3',
      title: 'Check Eligibility',
      desc: readinessPercentage !== undefined ? `${readinessPercentage}% readiness calculated` : 'Run rule-based comparison',
      icon: CheckCircle2,
      isDone: readinessPercentage !== undefined && readinessPercentage > 0,
      badge: readinessPercentage !== undefined ? `${readinessPercentage}% match` : 'Instant'
    }
  ];

  return (
    <div className="bg-white border-b border-slate-200/90 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          
          {/* Journey Header Tag */}
          <div className="flex items-center space-x-2 shrink-0">
            <span className="text-[10px] font-black uppercase tracking-wider text-blue-700 bg-blue-50 border border-blue-200/80 px-2.5 py-1 rounded-md">
              Student Workflow
            </span>
            <span className="text-xs text-slate-500 font-medium hidden sm:inline">
              End-to-End Decision Journey:
            </span>
          </div>

          {/* Steps Horizontal Flow */}
          <div className="flex items-center gap-1 sm:gap-3 overflow-x-auto pb-1 sm:pb-0">
            {steps.map((step, idx) => {
              const isActive = activeTab === step.id;
              const Icon = step.icon;

              return (
                <React.Fragment key={step.id}>
                  <button
                    onClick={() => setActiveTab(step.id)}
                    className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl text-left transition shrink-0 ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/80'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-extrabold ${
                      isActive 
                        ? 'bg-white text-blue-700' 
                        : step.isDone 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-slate-200 text-slate-700'
                    }`}>
                      {step.number}
                    </div>

                    <div className="flex flex-col">
                      <span className="text-xs font-bold leading-tight">
                        {step.title}
                      </span>
                      <span className={`text-[10px] truncate max-w-[130px] ${isActive ? 'text-blue-100' : 'text-slate-500'}`}>
                        {step.desc}
                      </span>
                    </div>

                    {step.isDone && !isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                    )}
                  </button>

                  {idx < steps.length - 1 && (
                    <ArrowRight className="w-3.5 h-3.5 text-slate-300 shrink-0 hidden sm:block" />
                  )}
                </React.Fragment>
              );
            })}
          </div>

        </div>
      </div>
    </div>
  );
}
