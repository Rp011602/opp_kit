import React, { useState, useMemo } from 'react';
import { 
  Search, Filter, Briefcase, GraduationCap, Trophy, 
  Sparkles, PlusCircle, ArrowUpDown, CheckSquare 
} from 'lucide-react';
import OpportunityCard from './OpportunityCard';

export default function OpportunityList({ 
  opportunities, 
  selectedOpp, 
  onSelectForCheck, 
  onViewDetails, 
  onOpenCustomModal,
  onEditOpportunity
}) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('default'); // 'default', 'deadline'

  const categories = [
    { label: 'All Categories', value: 'All', icon: Sparkles },
    { label: 'Internships', value: 'Internships', icon: Briefcase },
    { label: 'Scholarships', value: 'Scholarships', icon: GraduationCap },
    { label: 'Competitions', value: 'Competitions', icon: Trophy }
  ];

  const filteredOpportunities = useMemo(() => {
    return opportunities.filter(opp => {
      // Category filter
      if (activeCategory !== 'All' && opp.category !== activeCategory) {
        return false;
      }
      // Search query filter (matches title, organization, skills, description)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = opp.title.toLowerCase().includes(q);
        const matchesOrg = opp.organization.toLowerCase().includes(q);
        const matchesDesc = opp.description.toLowerCase().includes(q);
        const matchesSkills = opp.criteria?.requiredSkills?.some(s => s.toLowerCase().includes(q));
        if (!matchesTitle && !matchesOrg && !matchesDesc && !matchesSkills) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'deadline') {
        return new Date(a.deadline) - new Date(b.deadline);
      }
      return 0;
    });
  }, [opportunities, activeCategory, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Hero / Intro Banner */}
      <div className="bg-gradient-to-r from-[#0f1f32] to-[#1e344e] rounded-3xl p-6 sm:p-10 text-white mb-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-400/30 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Smart Opportunity Engine</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight mb-2">
            Discover Verified Opportunities & Check Your Eligibility
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Select an internship, scholarship, or hackathon below to run a transparent rule-based analysis against your student profile.
          </p>
        </div>

        {/* Decorative background glow */}
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Control Bar: Categories, Search & Custom Action */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-2xs mb-8 space-y-4">
        
        {/* Category Pills & Add Custom Button */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            {categories.map(cat => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.value;
              return (
                <button
                  key={cat.value}
                  type="button"
                  onClick={() => setActiveCategory(cat.value)}
                  className={`inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={onOpenCustomModal}
            className="inline-flex items-center justify-center space-x-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-2xs self-start md:self-auto"
          >
            <PlusCircle className="w-4 h-4 text-blue-600" />
            <span>Create Custom Opportunity</span>
          </button>
        </div>

        {/* Search & Sort Row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="relative w-full sm:w-96">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by role, skill (e.g. React, Python), company..."
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-xs text-slate-900"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-end">
            <span className="text-xs font-semibold text-slate-500">
              Showing <span className="text-slate-900 font-bold">{filteredOpportunities.length}</span> opportunities
            </span>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-xs bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="default">Sort: Default</option>
              <option value="deadline">Sort: Closest Deadline</option>
            </select>
          </div>
        </div>

      </div>

      {/* Grid of Opportunity Cards */}
      {filteredOpportunities.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center max-w-xl mx-auto">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-base mb-1">No opportunities match your filter</h3>
          <p className="text-xs text-slate-500 mb-4">
            Try adjusting your search query or reset category filter to see available opportunities.
          </p>
          <button
            type="button"
            onClick={() => { setActiveCategory('All'); setSearchQuery(''); }}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 underline"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOpportunities.map(opp => (
            <OpportunityCard
              key={opp.id}
              opportunity={opp}
              onSelectForCheck={onSelectForCheck}
              onViewDetails={onViewDetails}
              onEditOpportunity={onEditOpportunity}
              isSelected={selectedOpp?.id === opp.id}
            />
          ))}
        </div>
      )}

    </div>
  );
}
