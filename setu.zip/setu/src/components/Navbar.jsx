import React from 'react';
import { Sparkles, Compass, UserCircle, CheckCircle2, Building, PlusCircle } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, selectedOpp, onNewCustomOpp, profileCompleteness }) {
  return (
    <header className="sticky top-0 z-40 bg-[#0f1f32] text-white shadow-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => setActiveTab('explore')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-400 flex items-center justify-center shadow-inner group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl tracking-tight text-white">
                  Opportunity<span className="text-blue-400">Kit</span>
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-400/30 px-1.5 py-0.5 rounded">
                  SETU 2026 • PS-03
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Smart Explainable Student Eligibility Checker</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center space-x-1 sm:space-x-2">
            <button
              onClick={() => setActiveTab('explore')}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'explore'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span>Opportunities</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors relative ${
                activeTab === 'profile'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <UserCircle className="w-4 h-4" />
              <span>Student Profile</span>
              {profileCompleteness > 0 && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-1 ${
                  profileCompleteness === 100 
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {profileCompleteness}%
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('checker')}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'checker'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : selectedOpp
                  ? 'text-blue-300 bg-blue-950/60 border border-blue-800/60 hover:bg-blue-900/40'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span className="hidden md:inline">Eligibility Checker</span>
              <span className="md:hidden">Checker</span>
              {selectedOpp && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse ml-1" title="Opportunity selected" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('colleges')}
              className={`hidden md:flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'colleges'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Building className="w-4 h-4" />
              <span>For Colleges</span>
              <span className="text-[9px] bg-slate-800 border border-slate-700 text-slate-400 px-1.5 py-0.2 rounded font-semibold uppercase hidden xl:inline">Future</span>
            </button>
          </nav>

          {/* Quick Action */}
          <div className="flex items-center space-x-2">
            <button
              onClick={onNewCustomOpp}
              className="hidden sm:inline-flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-blue-300 border border-slate-700 text-xs font-semibold px-3 py-2 rounded-lg transition-colors shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5 text-blue-400" />
              <span>Add Custom Opp</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
}
