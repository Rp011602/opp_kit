import React from 'react';
import { Sparkles, Check, Building, ShieldCheck, Zap, ArrowRight, Star } from 'lucide-react';

export default function FutureMonetization() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Header Banner */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Product Roadmap & Sustainability</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Monetization & Future Revenue Architecture
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          OpportunityKit is built with a sustainable freemium model that keeps basic rule evaluation free forever for every student while unlocking high-value premium features and institutional placement cell partnerships.
        </p>
        <div className="inline-block bg-amber-50 border border-amber-300 text-amber-900 text-xs font-bold px-3 py-1 rounded-full">
          Note: Clearly labeled as conceptual roadmap features for SETU 2026 Round 2
        </div>
      </div>

      {/* Pricing / Tiers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
        
        {/* Tier 1: Free Basic (Current Live Core) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-7 flex flex-col justify-between shadow-2xs">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Tier 1</span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-emerald-200">
                Live in Prototype
              </span>
            </div>
            <h3 className="text-xl font-extrabold text-slate-900 mb-1">Free Basic Checker</h3>
            <p className="text-xs text-slate-500 mb-5">
              Empowering every student with transparent, explainable eligibility analysis.
            </p>
            <div className="flex items-baseline space-x-1 mb-6">
              <span className="text-4xl font-black text-slate-900">₹0</span>
              <span className="text-xs text-slate-500 font-medium">/ forever free</span>
            </div>

            <ul className="space-y-3 text-xs text-slate-600">
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Unlimited eligibility checks on all 3 categories</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Rule-based MATCH / MISMATCH / MISSING INFO</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Personalized gap checklist & explanations</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Custom opportunity manual entry & testing</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>100% private client-side browser storage</span>
              </li>
            </ul>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100">
            <span className="w-full inline-block text-center text-xs font-bold py-2.5 rounded-xl bg-slate-100 text-slate-700">
              Current Active Experience
            </span>
          </div>
        </div>

        {/* Tier 2: Premium Student Tracker (Future B2C) */}
        <div className="bg-white rounded-3xl border-2 border-blue-600 p-7 flex flex-col justify-between shadow-md relative">
          <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[11px] font-bold px-3 py-0.5 rounded-full uppercase tracking-wider shadow-sm flex items-center space-x-1">
            <Star className="w-3 h-3 fill-current" />
            <span>Future Student Premium</span>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-700">Tier 2 (B2C)</span>
              <span className="bg-blue-100 text-blue-800 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-blue-200">
                Future Feature
              </span>
            </div>
            <h3 className="text-xl font-extrabold text-slate-900 mb-1">Opportunity Tracker Pro</h3>
            <p className="text-xs text-slate-500 mb-5">
              Automated notifications, deadline alarms, and targeted skill learning tracks.
            </p>
            <div className="flex items-baseline space-x-1 mb-6">
              <span className="text-4xl font-black text-slate-900">₹49</span>
              <span className="text-xs text-slate-500 font-medium">/ month (micro-sub)</span>
            </div>

            <ul className="space-y-3 text-xs text-slate-600">
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-blue-600 shrink-0" />
                <span>SMS & WhatsApp deadline reminder alerts</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Curated mini-courses to resolve missing skills</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Resume ATS keyword scanner against job descriptions</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Application history tracking & pipeline kanban</span>
              </li>
            </ul>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100">
            <span className="w-full inline-block text-center text-xs font-bold py-2.5 rounded-xl bg-blue-50 text-blue-700 border border-blue-200">
              Planned Q3 2026
            </span>
          </div>
        </div>

        {/* Tier 3: College Subscriptions (Future B2B) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-7 flex flex-col justify-between shadow-2xs">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Tier 3 (B2B)</span>
              <span className="bg-purple-100 text-purple-800 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-purple-200">
                Institutional
              </span>
            </div>
            <h3 className="text-xl font-extrabold text-slate-900 mb-1">Campus Placement Cell (TPO)</h3>
            <p className="text-xs text-slate-500 mb-5">
              Empower Training & Placement Officers with batch-wide eligibility filtering.
            </p>
            <div className="flex items-baseline space-x-1 mb-6">
              <span className="text-4xl font-black text-slate-900">₹25,000</span>
              <span className="text-xs text-slate-500 font-medium">/ year per institution</span>
            </div>

            <ul className="space-y-3 text-xs text-slate-600">
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-purple-600 shrink-0" />
                <span>One-click batch filtering against company drive criteria</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Auto-generate eligible student rosters for recruiter visits</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Institutional skill-gap analytics across departments</span>
              </li>
              <li className="flex items-center space-x-2">
                <Check className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Placement audit readiness & NAAC compliance reports</span>
              </li>
            </ul>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100">
            <span className="w-full inline-block text-center text-xs font-bold py-2.5 rounded-xl bg-purple-50 text-purple-700 border border-purple-200">
              Institutional Pilot Concept
            </span>
          </div>
        </div>

      </div>

      {/* Sustainable Impact Callout */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <h3 className="text-lg font-bold">Why This Business Model Works for India</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            By keeping the core eligibility analysis free, OpportunityKit eliminates the financial friction that prevents tier-2/3 college students from discovering scholarships and national opportunities. B2B institutional monetization subsidizes the free tier while solving placement overhead for colleges.
          </p>
        </div>
        <div className="flex items-center space-x-3 shrink-0">
          <div className="px-4 py-2 rounded-xl bg-white/10 text-xs font-bold text-slate-200 border border-white/10">
            SETU 2026 Problem Statement PS-03
          </div>
        </div>
      </div>

    </div>
  );
}
