import React from 'react';
import { Building, GraduationCap, Users, ShieldAlert, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';

export default function ForColleges({ onBackToStudentFlow }) {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0f1f32] to-[#1e344e] rounded-3xl p-6 sm:p-10 text-white shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-400/30">
            <Building className="w-3.5 h-3.5 text-blue-400" />
            <span>Future Business Potential • SETU 2026</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
            For Colleges & Placement Cells
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            While OpportunityKit is built <strong className="text-white">student-first</strong> for this MVP, our long-term sustainable business model targets educational institutions and college placement cells as future paying customers.
          </p>
          <div className="pt-2">
            <span className="inline-block bg-amber-500/20 border border-amber-400/40 text-amber-200 text-xs font-bold px-3 py-1 rounded-full">
              Non-Functional Roadmap Preview — No Admin Login Needed for Student MVP
            </span>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Target User & Business Model Clarification */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Card 1: Primary Users (Students) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 block mb-0.5">Primary End Users</span>
            <h3 className="text-lg font-extrabold text-slate-900">College Students (100% Free)</h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Students face severe information asymmetry when applying for internships, scholarships, and hackathons. OpportunityKit remains permanently free for students to discover criteria, check eligibility, and understand their skill/document gaps.
          </p>
          <ul className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-100">
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Zero login barrier or fee for student eligibility checks</span>
            </li>
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Personalized action checklist to become eligible</span>
            </li>
          </ul>
        </div>

        {/* Card 2: Future Paying Customers (Institutions) */}
        <div className="bg-white rounded-2xl border border-blue-200 p-6 shadow-2xs space-y-3 bg-gradient-to-b from-blue-50/40 to-white">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 block mb-0.5">Future Paying Customers</span>
            <h3 className="text-lg font-extrabold text-slate-900">College Placement Cells & TPOs</h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Training & Placement Officers (TPOs) spend hundreds of hours manually cross-checking student CGPAs, branches, backlogs, and resume documents across Excel spreadsheets for visiting corporate recruiters.
          </p>
          <ul className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-100">
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>B2B annual campus subscription (₹25k – ₹50k / year)</span>
            </li>
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Institutional placement readiness & NAAC audit data</span>
            </li>
          </ul>
        </div>

      </div>

      {/* 3 Future Institutional Features */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Institutional Roadmap</span>
          <h3 className="text-xl font-extrabold text-slate-900 mt-1">
            Planned College Subscription Features
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Key capabilities envisioned for educational institutions in future phases:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              1
            </div>
            <h4 className="text-sm font-bold text-slate-900">Batch-Wide Opportunity Screening</h4>
            <p className="text-slate-600 leading-relaxed">
              When a recruiter visits with complex requirements (e.g., CSE/IT only, CGPA &ge; 7.5, no active backlogs, Python proficiency), TPOs can run a 1-click batch query across 1,000+ students.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
              2
            </div>
            <h4 className="text-sm font-bold text-slate-900">Campus Skill Gap Diagnostics</h4>
            <p className="text-slate-600 leading-relaxed">
              Analytics aggregate missing student skills across cohorts (e.g. "45% of 3rd years lack Git/Docker experience"), allowing HODs to organize targeted bridge bootcamps before placement season.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              3
            </div>
            <h4 className="text-sm font-bold text-slate-900">Automated Shortlist Export</h4>
            <p className="text-slate-600 leading-relaxed">
              Instant generation of verified student rosters, filtered transcripts, and verified resume packets formatted to corporate hiring specifications.
            </p>
          </div>

        </div>
      </div>

      {/* Scope Transparency Callout */}
      <div className="bg-slate-100 rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
        <div className="space-y-1 max-w-xl">
          <div className="flex items-center space-x-1.5 font-bold text-slate-800">
            <ShieldAlert className="w-4 h-4 text-slate-600" />
            <span>Deliberate Student-First Scope Design</span>
          </div>
          <p className="text-slate-600 leading-relaxed">
            To ensure maximum speed, privacy, and usability for SETU 2026, OpportunityKit omits complex teacher logins, admin portals, and role switches in this MVP. The student workflow works end-to-end without friction.
          </p>
        </div>

        <button
          type="button"
          onClick={onBackToStudentFlow}
          className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition shrink-0 self-start sm:self-auto shadow-2xs"
        >
          <span>Return to Student Workflow</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

    </div>
  );
}
