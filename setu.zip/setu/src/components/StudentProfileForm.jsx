import React, { useState } from 'react';
import { 
  User, BookOpen, GraduationCap, Award, FileText, 
  GitBranch, Globe, Users, DollarSign, Check, RotateCcw, 
  Sparkles, Plus, X, AlertCircle, Save
} from 'lucide-react';
import { 
  DEFAULT_BRANCHES, 
  YEARS_OF_STUDY, 
  AVAILABLE_DOCUMENTS, 
  COMMON_SKILLS, 
  SAMPLE_STUDENT_PROFILES, 
  EMPTY_STUDENT_PROFILE 
} from '../types/defaultProfile';

export default function StudentProfileForm({ 
  profile, 
  onSaveProfile, 
  onProceedToChecker, 
  selectedOpp = null, 
  opportunities = [] 
}) {
  const [formData, setFormData] = useState(profile || EMPTY_STUDENT_PROFILE);
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [saveToast, setSaveToast] = useState(false);

  // Compute all custom requirements across selectedOpp and all opportunities
  const allCustomRequirements = React.useMemo(() => {
    const list = [];
    const seenIds = new Set();

    if (selectedOpp?.criteria?.customRequirements) {
      selectedOpp.criteria.customRequirements.forEach(req => {
        const key = req.id || req.name;
        if (!seenIds.has(key)) {
          seenIds.add(key);
          list.push({ ...req, source: selectedOpp.title, isSelectedOpp: true });
        }
      });
    }

    (opportunities || []).forEach(opp => {
      if (opp.criteria?.customRequirements) {
        opp.criteria.customRequirements.forEach(req => {
          const key = req.id || req.name;
          if (!seenIds.has(key)) {
            seenIds.add(key);
            list.push({ ...req, source: opp.title, isSelectedOpp: false });
          }
        });
      }
    });

    return list;
  }, [selectedOpp, opportunities]);

  const handleCustomResponseChange = (reqKey, value) => {
    setFormData(prev => ({
      ...prev,
      customResponses: {
        ...(prev.customResponses || {}),
        [reqKey]: value
      }
    }));
  };

  // Sync internal state if external profile changes
  React.useEffect(() => {
    if (profile) {
      setFormData(profile);
    }
  }, [profile]);

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleToggleSkill = (skill) => {
    setFormData(prev => {
      const currentSkills = prev.skills || [];
      if (currentSkills.includes(skill)) {
        return { ...prev, skills: currentSkills.filter(s => s !== skill) };
      } else {
        return { ...prev, skills: [...currentSkills, skill] };
      }
    });
  };

  const handleAddCustomSkill = (e) => {
    e.preventDefault();
    const trimmed = customSkillInput.trim();
    if (trimmed && !(formData.skills || []).includes(trimmed)) {
      setFormData(prev => ({
        ...prev,
        skills: [...(prev.skills || []), trimmed]
      }));
      setCustomSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove) => {
    setFormData(prev => ({
      ...prev,
      skills: (prev.skills || []).filter(s => s !== skillToRemove)
    }));
  };

  const handleToggleDocument = (doc) => {
    setFormData(prev => {
      const currentDocs = prev.documents || [];
      if (currentDocs.includes(doc)) {
        return { ...prev, documents: currentDocs.filter(d => d !== doc) };
      } else {
        return { ...prev, documents: [...currentDocs, doc] };
      }
    });
  };

  const handleLoadSample = (sampleProfile) => {
    setFormData(sampleProfile);
    onSaveProfile(sampleProfile);
    triggerSaveToast("Sample Profile Loaded");
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset your profile to empty?")) {
      setFormData(EMPTY_STUDENT_PROFILE);
      onSaveProfile(EMPTY_STUDENT_PROFILE);
      triggerSaveToast("Profile Cleared");
    }
  };

  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    onSaveProfile(formData);
    triggerSaveToast("Profile Saved to Local Storage");
  };

  const triggerSaveToast = (msg) => {
    setSaveToast(msg || "Saved");
    setTimeout(() => setSaveToast(false), 2500);
  };

  // Calculate completeness score
  const calculateCompleteness = () => {
    let score = 0;
    if (formData.fullName) score += 10;
    if (formData.yearOfStudy) score += 15;
    if (formData.branch) score += 15;
    if (formData.cgpa) score += 15;
    if (formData.skills && formData.skills.length > 0) score += 20;
    if (formData.documents && formData.documents.length > 0) score += 15;
    if (formData.githubUrl) score += 10;
    return Math.min(100, score);
  };

  const completeness = calculateCompleteness();

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      
      {/* Header & Preset Switcher */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 sm:p-8 shadow-sm mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 mb-2">
              <User className="w-3.5 h-3.5" />
              <span>Step 1: Student Foundation</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Student Profile
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Your details are stored securely in your browser's <code className="bg-slate-100 text-slate-700 px-1 py-0.5 rounded text-xs">localStorage</code> and checked against opportunity requirements.
            </p>
          </div>

          {/* Quick presets for instant hackathon testing */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Quick Presets:</span>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_STUDENT_PROFILES.map(sample => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => handleLoadSample(sample.profile)}
                  className="inline-flex items-center space-x-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 transition border border-slate-200"
                >
                  <Sparkles className="w-3 h-3 text-blue-500" />
                  <span>{sample.profile.fullName.split(' ')[0]}</span>
                </button>
              ))}
              <button
                type="button"
                onClick={handleReset}
                title="Reset to blank profile"
                className="inline-flex items-center space-x-1 text-xs font-medium px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 transition border border-rose-200"
              >
                <RotateCcw className="w-3 h-3" />
                <span className="hidden sm:inline">Reset</span>
              </button>
            </div>
          </div>
        </div>

        {/* Completeness Bar */}
        <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Profile Readiness:</span>
            <span className={`text-sm font-extrabold ${completeness === 100 ? 'text-emerald-600' : 'text-blue-600'}`}>
              {completeness}% Complete
            </span>
          </div>
          <div className="w-full sm:w-72 bg-slate-100 rounded-full h-2.5 overflow-hidden">
            <div 
              className={`h-2.5 rounded-full transition-all duration-500 ${
                completeness >= 80 ? 'bg-emerald-500' : completeness >= 50 ? 'bg-blue-600' : 'bg-amber-500'
              }`}
              style={{ width: `${completeness}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Profile Form */}
      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* Section 1: Basic & Academic Information */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center space-x-3 pb-4 mb-6 border-b border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-blue-100/70 text-blue-700 flex items-center justify-center font-bold">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Academic Credentials</h2>
              <p className="text-xs text-slate-500">Degree, cohort, and academic standing</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => handleChange('fullName', e.target.value)}
                placeholder="e.g. Aarav Sharma"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900"
                required
              />
            </div>

            {/* Email Address */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="aarav@college.edu"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900"
              />
            </div>

            {/* Year of Study */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Year of Study <span className="text-rose-500">*</span>
              </label>
              <select
                value={formData.yearOfStudy}
                onChange={(e) => handleChange('yearOfStudy', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900 bg-white"
                required
              >
                <option value="">-- Select Current Year --</option>
                {YEARS_OF_STUDY.map(y => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            {/* Branch / Stream */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Branch / Academic Discipline <span className="text-rose-500">*</span>
              </label>
              <select
                value={formData.branch}
                onChange={(e) => handleChange('branch', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900 bg-white"
                required
              >
                <option value="">-- Select Degree / Branch --</option>
                {DEFAULT_BRANCHES.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* CGPA */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Cumulative CGPA (out of 10) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="10"
                  value={formData.cgpa}
                  onChange={(e) => handleChange('cgpa', e.target.value)}
                  placeholder="e.g. 8.45"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900 font-medium"
                />
                <span className="absolute right-3.5 top-2.5 text-xs font-bold text-slate-400">
                  / 10.0
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">Used for minimum grade cutoffs across applications</p>
            </div>
          </div>
        </div>

        {/* Section 2: Technical Skills */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center space-x-3 pb-4 mb-4 border-b border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-indigo-100/70 text-indigo-700 flex items-center justify-center font-bold">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Technical & Practical Skills</h2>
              <p className="text-xs text-slate-500">Pick from suggested skills or add your own custom stack</p>
            </div>
          </div>

          {/* Quick select tags */}
          <div className="mb-4">
            <span className="text-xs font-bold text-slate-600 block mb-2 uppercase tracking-wider">
              Quick Select Common Skills:
            </span>
            <div className="flex flex-wrap gap-2">
              {COMMON_SKILLS.map(skill => {
                const isSelected = (formData.skills || []).includes(skill);
                return (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => handleToggleSkill(skill)}
                    className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-600/30'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                    <span>{skill}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom skill input */}
          <div className="mb-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={customSkillInput}
                onChange={(e) => setCustomSkillInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCustomSkill(e);
                  }
                }}
                placeholder="Type a custom skill (e.g. Next.js, Flutter, OpenCV) & press Add"
                className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900"
              />
              <button
                type="button"
                onClick={handleAddCustomSkill}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl flex items-center space-x-1 transition shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Skill</span>
              </button>
            </div>
          </div>

          {/* Active profile skills display */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block mb-2">
              Currently Listed on Your Profile ({formData.skills?.length || 0}):
            </span>
            {(!formData.skills || formData.skills.length === 0) ? (
              <p className="text-xs text-slate-400 italic">No skills selected yet. Click any skill tag above to add.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {formData.skills.map(skill => (
                  <span
                    key={skill}
                    className="inline-flex items-center space-x-1.5 px-3 py-1 bg-white border border-blue-200 text-blue-900 rounded-lg text-xs font-medium shadow-2xs"
                  >
                    <span>{skill}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveSkill(skill)}
                      className="text-slate-400 hover:text-rose-600 transition"
                      title="Remove skill"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Section 3: Verified Documents Available */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center space-x-3 pb-4 mb-4 border-b border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-emerald-100/70 text-emerald-700 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Documents Currently Prepared</h2>
              <p className="text-xs text-slate-500">Check the paperwork you have ready for submission</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {AVAILABLE_DOCUMENTS.map(doc => {
              const isChecked = (formData.documents || []).includes(doc);
              return (
                <label
                  key={doc}
                  className={`flex items-start space-x-3 p-3.5 rounded-xl border cursor-pointer transition ${
                    isChecked
                      ? 'bg-emerald-50/60 border-emerald-300 text-emerald-900'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => handleToggleDocument(doc)}
                    className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <div className="text-xs font-semibold leading-relaxed">
                    {doc}
                  </div>
                </label>
              );
            })}
          </div>
        </div>

        {/* Section 4: Public Profiles & Socio-Economic (Optional Details) */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center space-x-3 pb-4 mb-6 border-b border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-sky-100/70 text-sky-700 flex items-center justify-center font-bold">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Links & Relevant Demographics</h2>
              <p className="text-xs text-slate-500">Required for specific competitions, scholarships, and technical screening</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* GitHub URL */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                <GitBranch className="w-3.5 h-3.5 text-slate-800" />
                <span>GitHub Profile URL</span>
              </label>
              <input
                type="url"
                value={formData.githubUrl}
                onChange={(e) => handleChange('githubUrl', e.target.value)}
                placeholder="https://github.com/your-username"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900"
              />
              <p className="text-[11px] text-slate-500 mt-1">Needed for open-source & technical internships</p>
            </div>

            {/* Portfolio URL */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                <Globe className="w-3.5 h-3.5 text-slate-800" />
                <span>Personal Portfolio / Demo Site</span>
              </label>
              <input
                type="url"
                value={formData.portfolioUrl}
                onChange={(e) => handleChange('portfolioUrl', e.target.value)}
                placeholder="https://yourportfolio.com"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900"
              />
              <p className="text-[11px] text-slate-500 mt-1">Projects, design showcases, or hosted apps</p>
            </div>

            {/* Family Income (LPA) - for scholarships */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                <DollarSign className="w-3.5 h-3.5 text-slate-800" />
                <span>Annual Family Income (in Lakhs INR)</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  value={formData.familyIncomeLpa}
                  onChange={(e) => handleChange('familyIncomeLpa', e.target.value)}
                  placeholder="e.g. 5.5"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900 font-medium"
                />
                <span className="absolute right-3.5 top-2.5 text-xs font-bold text-slate-400">
                  Lakhs / Year
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Evaluated strictly for income-based grants & scholarships</p>
            </div>

            {/* Team Size - for competitions */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                <Users className="w-3.5 h-3.5 text-slate-800" />
                <span>Hackathon / Team Size Available</span>
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={formData.teamSize}
                onChange={(e) => handleChange('teamSize', e.target.value)}
                placeholder="e.g. 3"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900 font-medium"
              />
              <p className="text-[11px] text-slate-500 mt-1">Number of members in your squad (1 for solo)</p>
            </div>
          </div>
        </div>

        {/* Section 5: Opportunity-Specific & Custom Questions */}
        {allCustomRequirements.length > 0 && (
          <div className="bg-white rounded-2xl border border-blue-200/90 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-6 border-b border-slate-100">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900">
                    Opportunity-Specific & Custom Criteria ({allCustomRequirements.length})
                  </h2>
                  <p className="text-xs text-slate-500">
                    Answer specialized requirements dynamically defined for selected internships, grants & challenges.
                  </p>
                </div>
              </div>

              {selectedOpp && (
                <span className="text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-3 py-1 rounded-full self-start sm:self-auto">
                  Selected Target: {selectedOpp.title}
                </span>
              )}
            </div>

            <div className="space-y-4">
              {allCustomRequirements.map(req => {
                const reqKey = req.id || req.name;
                const currentVal = (formData.customResponses || {})[req.id] ?? (formData.customResponses || {})[req.name] ?? '';
                const reqType = req.type || 'Text';

                return (
                  <div key={reqKey} className="p-4 bg-slate-50/80 rounded-xl border border-slate-200 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-white text-indigo-700 border border-indigo-200">
                          {reqType}
                        </span>
                        <label className="font-bold text-slate-900 text-xs">
                          {req.name}
                        </label>
                      </div>

                      <div className="flex items-center space-x-2 text-[11px]">
                        <span className="text-slate-500">Target Condition:</span>
                        <span className="font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
                          {reqType === 'Number' ? `${req.operator || '>='} ${req.value}` : reqType === 'Text' ? `${req.operator || 'contains'} "${req.value}"` : req.value}
                        </span>
                      </div>
                    </div>

                    {req.explanation && (
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        • {req.explanation}
                      </p>
                    )}

                    {/* DYNAMIC INPUT CONTROL */}
                    <div className="pt-1">
                      {reqType === 'Yes/No' && (
                        <div className="flex items-center space-x-2 max-w-xs">
                          <button
                            type="button"
                            onClick={() => handleCustomResponseChange(reqKey, 'Yes')}
                            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold border transition ${
                              String(currentVal).toLowerCase() === 'yes'
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => handleCustomResponseChange(reqKey, 'No')}
                            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold border transition ${
                              String(currentVal).toLowerCase() === 'no'
                                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            No
                          </button>
                          {currentVal && (
                            <button
                              type="button"
                              onClick={() => handleCustomResponseChange(reqKey, '')}
                              className="text-[10px] text-slate-400 hover:text-rose-600 underline ml-1"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                      )}

                      {reqType === 'Number' && (
                        <div className="flex items-center space-x-2 max-w-xs">
                          <input
                            type="number"
                            step="any"
                            value={currentVal}
                            onChange={(e) => handleCustomResponseChange(reqKey, e.target.value)}
                            placeholder={`Enter number (Condition: ${req.operator || '>='} ${req.value})`}
                            className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                          />
                        </div>
                      )}

                      {reqType === 'Text' && (
                        <div className="max-w-md">
                          <input
                            type="text"
                            value={currentVal}
                            onChange={(e) => handleCustomResponseChange(reqKey, e.target.value)}
                            placeholder={`Enter answer (Expected: "${req.value}")`}
                            className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                          />
                        </div>
                      )}

                      {reqType === 'Skill' && (
                        <div className="flex items-center space-x-2 max-w-sm">
                          <label className="flex items-center space-x-2 cursor-pointer bg-white px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium">
                            <input
                              type="checkbox"
                              checked={String(currentVal).toLowerCase() === 'yes' || (formData.skills || []).some(s => s.toLowerCase().includes(String(req.value || req.name).toLowerCase()))}
                              onChange={(e) => handleCustomResponseChange(reqKey, e.target.checked ? 'Yes' : 'No')}
                              className="rounded text-blue-600 focus:ring-blue-500"
                            />
                            <span>I have demonstrated skill in {req.value || req.name}</span>
                          </label>
                        </div>
                      )}

                      {reqType === 'Document' && (
                        <div className="flex items-center space-x-2 max-w-sm">
                          <label className="flex items-center space-x-2 cursor-pointer bg-white px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium">
                            <input
                              type="checkbox"
                              checked={String(currentVal).toLowerCase() === 'yes' || (formData.documents || []).some(d => d.toLowerCase().includes(String(req.value || req.name).toLowerCase()))}
                              onChange={(e) => handleCustomResponseChange(reqKey, e.target.checked ? 'Yes' : 'No')}
                              className="rounded text-blue-600 focus:ring-blue-500"
                            />
                            <span>I have prepared document: {req.value || req.name}</span>
                          </label>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Action Buttons & Feedback Toast */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
          <div className="flex items-center space-x-3">
            <button
              type="submit"
              className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition transform active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile to Browser</span>
            </button>

            {saveToast && (
              <span className="inline-flex items-center space-x-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg animate-fadeIn">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>{saveToast}</span>
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              handleSubmit();
              if (onProceedToChecker) onProceedToChecker();
            }}
            className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-[#0f1f32] hover:bg-slate-800 text-white font-bold text-sm shadow-md transition"
          >
            <span>Proceed to Explore Opportunities</span>
            <span>&rarr;</span>
          </button>
        </div>

      </form>
    </div>
  );
}
