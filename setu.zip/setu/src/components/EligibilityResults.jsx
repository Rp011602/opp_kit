import React, { useState } from 'react';
import { 
  CheckCircle2, XCircle, AlertTriangle, ArrowLeft, 
  UserCheck, Edit3, Share2, Printer, Sparkles, Filter, 
  HelpCircle, ChevronRight, Award, ExternalLink
} from 'lucide-react';
import { STATUS_TYPES } from '../utils/eligibilityEngine';
import ActionChecklist from './ActionChecklist';

export default function EligibilityResults({ 
  report, 
  opportunity, 
  profile, 
  onEditProfile, 
  onBackToOpportunities,
  onUpdateCustomResponse,
  onEditOpportunity
}) {
  const [activeFilter, setActiveFilter] = useState('ALL'); // 'ALL', 'MATCH', 'MISMATCH', 'MISSING_INFO'
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [tempAnswers, setTempAnswers] = useState({});

  const handleInlineAnswer = (reqKey, value) => {
    if (onUpdateCustomResponse) {
      onUpdateCustomResponse(reqKey, value);
    }
  };

  if (!report || !opportunity) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Sparkles className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-800 mb-2">No Opportunity Selected Yet</h2>
        <p className="text-sm text-slate-500 mb-6">Select an internship, scholarship, or competition to check your profile eligibility.</p>
        <button
          onClick={onBackToOpportunities}
          className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-sm hover:bg-blue-700 transition"
        >
          Browse Opportunities
        </button>
      </div>
    );
  }

  const { items, summary, actionItems } = report;

  // Filter items
  const filteredItems = items.filter(item => {
    if (activeFilter === 'ALL') return true;
    return item.status === activeFilter;
  });

  const handleCopyReport = () => {
    const reportText = `[OpportunityKit Eligibility Report]
Opportunity: ${opportunity.title} (${opportunity.organization})
Student: ${profile.fullName || 'Student'} (${profile.yearOfStudy || 'Year N/A'}, ${profile.branch || 'Branch N/A'})
Readiness: ${summary.readinessPercentage}% (${summary.verdictTitle})

Summary:
- Matched: ${summary.matchedCount}
- Mismatched: ${summary.mismatchedCount}
- Missing Info: ${summary.missingCount}

Action Checklist:
${actionItems.map(a => `- [ ] ${a.title}: ${a.description}`).join('\n')}

Evaluated via OpportunityKit (SETU 2026 PS-03)
`;
    navigator.clipboard.writeText(reportText).then(() => {
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2500);
    });
  };

  const handlePrint = () => {
    window.print();
  };

  // Status Badge styling helper
  const getStatusBadge = (status) => {
    switch (status) {
      case STATUS_TYPES.MATCH:
        return (
          <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>MATCH</span>
          </span>
        );
      case STATUS_TYPES.MISMATCH:
        return (
          <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300 shadow-2xs">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            <span>MISMATCH</span>
          </span>
        );
      case STATUS_TYPES.MISSING_INFO:
        return (
          <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-800 border border-amber-300 shadow-2xs">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span>MISSING INFO</span>
          </span>
        );
      default:
        return null;
    }
  };

  // Verdict Banner Color Styles
  const getVerdictStyle = (color) => {
    switch (color) {
      case 'emerald':
        return {
          bg: 'bg-emerald-900/90 text-white border-emerald-700',
          gauge: 'bg-emerald-400',
          badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
        };
      case 'amber':
        return {
          bg: 'bg-amber-950 text-white border-amber-800',
          gauge: 'bg-amber-400',
          badge: 'bg-amber-500/20 text-amber-300 border-amber-400/30'
        };
      case 'rose':
        return {
          bg: 'bg-rose-950 text-white border-rose-900',
          gauge: 'bg-rose-400',
          badge: 'bg-rose-500/20 text-rose-300 border-rose-400/30'
        };
      default:
        return {
          bg: 'bg-[#0f1f32] text-white border-slate-700',
          gauge: 'bg-blue-400',
          badge: 'bg-blue-500/20 text-blue-300 border-blue-400/30'
        };
    }
  };

  const verdictTheme = getVerdictStyle(summary.verdictColor);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Navigation Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBackToOpportunities}
          className="inline-flex items-center space-x-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3.5 py-2 rounded-xl transition shadow-2xs self-start"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Opportunities</span>
        </button>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onEditProfile}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3.5 py-2 rounded-xl transition shadow-2xs"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Profile & Recheck</span>
          </button>

          <button
            type="button"
            onClick={handleCopyReport}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl transition shadow-2xs"
            title="Copy evaluation summary"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{copyFeedback ? "Copied!" : "Share Report"}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl transition shadow-2xs"
            title="Print or save as PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print</span>
          </button>
        </div>
      </div>

      {/* Target Opportunity Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full border border-blue-200">
                {opportunity.category}
              </span>
              <span className="text-xs text-slate-500 font-medium">Evaluating Profile: <strong className="text-slate-800">{profile.fullName || 'Anonymous Student'}</strong></span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {opportunity.title}
            </h1>
            <p className="text-sm font-semibold text-slate-600 mt-1">
              {opportunity.organization} {opportunity.deadline && `• Deadline: ${opportunity.deadline}`}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onEditOpportunity && onEditOpportunity(opportunity)}
              className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold border border-blue-200 transition shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Add / Edit Custom Requirements</span>
            </button>

            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-right">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Evaluated Profile</span>
              <span className="text-xs font-bold text-slate-800">
                {profile.yearOfStudy || 'Year not set'} • {profile.cgpa ? `${profile.cgpa} CGPA` : 'CGPA not set'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Verdict & Readiness Dashboard Card */}
      <div className={`rounded-3xl border p-6 sm:p-8 shadow-sm ${verdictTheme.bg}`}>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          
          {/* Left: Summary text */}
          <div className="space-y-3 max-w-xl">
            <span className={`inline-block text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-full border ${verdictTheme.badge}`}>
              Explainable Evaluation Verdict
            </span>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
              {summary.verdictTitle}
            </h2>
            <p className="text-sm text-slate-200 leading-relaxed font-normal">
              {summary.verdictDescription}
            </p>
          </div>

          {/* Right: Readiness Percentage Metric & Count Badges */}
          <div className="flex flex-col sm:flex-row items-center gap-6 bg-black/20 p-5 rounded-2xl border border-white/10 shrink-0">
            
            {/* Big Circular/Progress Metric */}
            <div className="text-center sm:text-left">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1">
                Readiness Score
              </span>
              <div className="flex items-baseline space-x-1">
                <span className="text-5xl font-black tracking-tight text-white">
                  {summary.readinessPercentage}
                </span>
                <span className="text-2xl font-bold text-slate-300">%</span>
              </div>
              <div className="w-32 bg-white/20 rounded-full h-2 mt-2 overflow-hidden">
                <div 
                  className={`h-2 rounded-full ${verdictTheme.gauge}`} 
                  style={{ width: `${summary.readinessPercentage}%` }} 
                />
              </div>
            </div>

            {/* Counts Matrix */}
            <div className="grid grid-cols-3 gap-2 text-center border-t sm:border-t-0 sm:border-l border-white/15 pt-4 sm:pt-0 sm:pl-6">
              
              <div className="p-2.5 rounded-xl bg-white/10 border border-white/10">
                <span className="text-emerald-300 font-black text-xl block leading-none">
                  {summary.matchedCount}
                </span>
                <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider mt-1 block">
                  Matched
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 border border-white/10">
                <span className="text-rose-300 font-black text-xl block leading-none">
                  {summary.mismatchedCount}
                </span>
                <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider mt-1 block">
                  Mismatches
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 border border-white/10">
                <span className="text-amber-300 font-black text-xl block leading-none">
                  {summary.missingCount}
                </span>
                <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider mt-1 block">
                  Missing Info
                </span>
              </div>

            </div>

          </div>

        </div>
      </div>

      {/* Requirement Breakdown Section */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
        
        {/* Section Header & Filter Tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">
              Rule-by-Rule Eligibility Breakdown
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Transparent, explainable checks comparing each requirement against your profile.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setActiveFilter('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeFilter === 'ALL'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All ({summary.totalCount})
            </button>
            <button
              onClick={() => setActiveFilter(STATUS_TYPES.MATCH)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeFilter === STATUS_TYPES.MATCH
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
              }`}
            >
              Matched ({summary.matchedCount})
            </button>
            <button
              onClick={() => setActiveFilter(STATUS_TYPES.MISMATCH)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeFilter === STATUS_TYPES.MISMATCH
                  ? 'bg-rose-600 text-white'
                  : 'bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200'
              }`}
            >
              Mismatched ({summary.mismatchedCount})
            </button>
            <button
              onClick={() => setActiveFilter(STATUS_TYPES.MISSING_INFO)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeFilter === STATUS_TYPES.MISSING_INFO
                  ? 'bg-amber-600 text-white'
                  : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
              }`}
            >
              Missing Info ({summary.missingCount})
            </button>
          </div>
        </div>

        {/* Requirements Cards List */}
        <div className="space-y-4">
          {filteredItems.map(item => (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border transition-all ${
                item.status === STATUS_TYPES.MATCH
                  ? 'bg-emerald-50/20 border-emerald-200 hover:border-emerald-300'
                  : item.status === STATUS_TYPES.MISMATCH
                  ? 'bg-rose-50/20 border-rose-200 hover:border-rose-300'
                  : 'bg-amber-50/20 border-amber-200 hover:border-amber-300'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      {item.category}
                    </span>
                    {item.isCritical && (
                      <span className="text-[9px] font-extrabold uppercase tracking-wider text-rose-700 bg-rose-100 px-1.5 py-0.2 rounded">
                        Mandatory
                      </span>
                    )}
                  </div>
                  <h4 className="font-extrabold text-slate-900 text-base">
                    {item.label}
                  </h4>
                </div>

                <div>
                  {getStatusBadge(item.status)}
                </div>
              </div>

              {/* Expected vs Student Comparison Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3.5 text-xs">
                <div className="p-3 bg-white/90 rounded-xl border border-slate-200/80">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Expected Requirement
                  </span>
                  <span className="font-bold text-slate-800 leading-snug">
                    {item.expected}
                  </span>
                </div>

                <div className="p-3 bg-white/90 rounded-xl border border-slate-200/80">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                    Your Profile Value
                  </span>
                  <span className={`font-bold leading-snug ${
                    item.status === STATUS_TYPES.MATCH 
                      ? 'text-emerald-700' 
                      : item.status === STATUS_TYPES.MISMATCH 
                      ? 'text-rose-700' 
                      : 'text-amber-700 italic'
                  }`}>
                    {item.studentValue}
                  </span>
                </div>
              </div>

              {/* Natural Language Explanation */}
              <div className="flex items-start space-x-2 text-xs bg-white/60 p-3 rounded-xl border border-slate-100">
                <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <p className="text-slate-600 leading-relaxed font-medium">
                  {item.explanation}
                </p>
              </div>

              {/* DYNAMIC CLARIFICATION / INLINE ANSWER BOX FOR CUSTOM REQUIREMENTS */}
              {item.isCustom && item.customReq && (
                <div className="p-3.5 bg-white/95 rounded-xl border border-blue-200 mt-2.5 space-y-2 shadow-2xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="text-[11px] font-bold text-slate-800">
                      {item.status === STATUS_TYPES.MISSING_INFO 
                        ? "Clarify & Provide Answer (Never guess):" 
                        : "Update Your Response & Recalculate:"}
                    </span>
                    <span className="text-[10px] font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200 self-start sm:self-auto">
                      Requirement Type: {item.customReq.type}
                    </span>
                  </div>

                  {item.customReq.type === 'Yes/No' && (
                    <div className="flex items-center space-x-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleInlineAnswer(item.id, 'Yes')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition border ${
                          String(item.studentValue).toLowerCase() === 'yes'
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        Yes
                      </button>
                      <button
                        type="button"
                        onClick={() => handleInlineAnswer(item.id, 'No')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition border ${
                          String(item.studentValue).toLowerCase() === 'no'
                            ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        No
                      </button>
                      {item.status !== STATUS_TYPES.MISSING_INFO && (
                        <button
                          type="button"
                          onClick={() => handleInlineAnswer(item.id, '')}
                          className="text-[10px] text-slate-400 hover:text-rose-600 underline ml-2"
                        >
                          Clear Answer
                        </button>
                      )}
                    </div>
                  )}

                  {item.customReq.type === 'Number' && (
                    <div className="flex items-center space-x-2 pt-1 max-w-sm">
                      <input
                        type="number"
                        placeholder="Enter numeric value"
                        value={tempAnswers[item.id] !== undefined ? tempAnswers[item.id] : (item.studentValue.includes('Not') ? '' : item.studentValue)}
                        onChange={(e) => setTempAnswers(prev => ({ ...prev, [item.id]: e.target.value }))}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20 w-40"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const val = tempAnswers[item.id];
                          if (val !== undefined && val !== '') {
                            handleInlineAnswer(item.id, Number(val));
                          }
                        }}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-2xs transition shrink-0"
                      >
                        Save & Recheck
                      </button>
                    </div>
                  )}

                  {item.customReq.type === 'Text' && (
                    <div className="flex items-center space-x-2 pt-1 max-w-md">
                      <input
                        type="text"
                        placeholder={`Your response (Expected: "${item.customReq.value}")`}
                        value={tempAnswers[item.id] !== undefined ? tempAnswers[item.id] : (item.studentValue.includes('Not') ? '' : item.studentValue.replace(/"/g, ''))}
                        onChange={(e) => setTempAnswers(prev => ({ ...prev, [item.id]: e.target.value }))}
                        className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const val = tempAnswers[item.id];
                          if (val !== undefined) {
                            handleInlineAnswer(item.id, val);
                          }
                        }}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-2xs transition shrink-0"
                      >
                        Save & Recheck
                      </button>
                    </div>
                  )}

                  {item.customReq.type === 'Skill' && (
                    <div className="flex items-center space-x-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleInlineAnswer(item.id, 'Yes')}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition shadow-2xs"
                      >
                        Mark Skill Acquired & Recheck
                      </button>
                    </div>
                  )}

                  {item.customReq.type === 'Document' && (
                    <div className="flex items-center space-x-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleInlineAnswer(item.id, 'Yes')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition shadow-2xs"
                      >
                        Mark Document Ready & Recheck
                      </button>
                    </div>
                  )}
                </div>
              )}

            </div>
          ))}
        </div>

      </div>

      {/* Personalized Action Checklist */}
      <ActionChecklist 
        actionItems={actionItems} 
        onEditProfile={onEditProfile}
      />

    </div>
  );
}
