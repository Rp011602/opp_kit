import React from 'react';
import { X, Calendar, MapPin, Award, CheckCircle2, FileText, Code, Users, DollarSign, Sparkles, Edit3 } from 'lucide-react';

export default function OpportunityModal({ opportunity, onClose, onCheckEligibility, onEditOpportunity }) {
  if (!opportunity) return null;

  const { criteria } = opportunity;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white flex items-start justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded-full inline-block mb-2">
              {opportunity.category}
            </span>
            <h2 className="text-xl font-extrabold tracking-tight text-white mb-1">
              {opportunity.title}
            </h2>
            <p className="text-xs text-slate-300 font-medium">
              {opportunity.organization} {opportunity.location && `• ${opportunity.location}`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-700">
          
          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Overview</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-100">
              {opportunity.description}
            </p>
          </div>

          {/* Key Facts / Metadata */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Deadline</span>
              <span className="text-xs font-bold text-slate-800">{opportunity.deadline || 'Rolling'}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Stipend / Grant</span>
              <span className="text-xs font-bold text-emerald-700">{opportunity.stipendOrPrize || 'N/A'}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 col-span-2 sm:col-span-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Min CGPA</span>
              <span className="text-xs font-bold text-slate-800">
                {criteria?.minCgpa ? `≥ ${criteria.minCgpa}` : 'No strict cutoff'}
              </span>
            </div>
          </div>

          {/* Requirements Breakdown */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">Eligibility & Requirements</h3>
            
            <div className="space-y-2.5 text-xs">
              <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800">Target Cohort / Years: </span>
                  <span className="text-slate-600">{criteria?.allowedYears?.join(", ") || "All academic years"}</span>
                </div>
              </div>

              <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800">Eligible Branches: </span>
                  <span className="text-slate-600">
                    {criteria?.allowedBranches?.includes("Any") ? "All Branches (Open to any discipline)" : criteria?.allowedBranches?.join(", ")}
                  </span>
                </div>
              </div>

              {criteria?.requiredSkills && criteria.requiredSkills.length > 0 && (
                <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <Code className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Technical Skills: </span>
                    <span className="text-slate-600">{criteria.requiredSkills.join(", ")}</span>
                  </div>
                </div>
              )}

              {criteria?.requiredDocuments && criteria.requiredDocuments.length > 0 && (
                <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <FileText className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Documents Needed: </span>
                    <span className="text-slate-600">{criteria.requiredDocuments.join("; ")}</span>
                  </div>
                </div>
              )}

              {criteria?.maxFamilyIncomeLpa && (
                <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <DollarSign className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Income Limit: </span>
                    <span className="text-slate-600">Annual Family Income ≤ ₹{criteria.maxFamilyIncomeLpa} LPA</span>
                  </div>
                </div>
              )}

              {criteria?.minTeamSize && (
                <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <Users className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Team Size: </span>
                    <span className="text-slate-600">
                      {criteria.minTeamSize === criteria.maxTeamSize ? `${criteria.minTeamSize} members` : `${criteria.minTeamSize} - ${criteria.maxTeamSize || '+'} members`}
                    </span>
                  </div>
                </div>
              )}

              {/* Dynamic Custom Requirements Display */}
              {criteria?.customRequirements && criteria.customRequirements.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-200">
                  <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider block">
                    Specialized / Custom Criteria ({criteria.customRequirements.length}):
                  </span>
                  {criteria.customRequirements.map(req => (
                    <div key={req.id} className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-indigo-50/50 border border-indigo-100">
                      <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-[10px] font-black uppercase px-1.5 py-0.2 rounded bg-white text-indigo-700 border border-indigo-200">
                            {req.type}
                          </span>
                          <span className="font-bold text-slate-900">{req.name}</span>
                        </div>
                        <div className="text-slate-600">
                          Condition: <strong className="text-slate-800">{req.type === 'Number' ? `${req.operator || '>='} ${req.value}` : req.type === 'Text' ? `${req.operator || 'contains'} "${req.value}"` : req.value}</strong>
                        </div>
                        {req.explanation && (
                          <div className="text-slate-500 italic">• {req.explanation}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div>
            {onEditOpportunity && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onEditOpportunity(opportunity);
                }}
                className="inline-flex items-center space-x-1 text-xs font-bold text-blue-600 hover:text-blue-800 p-2 rounded-lg hover:bg-blue-50 transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit / Add Custom Rules</span>
              </button>
            )}
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-xl"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                onCheckEligibility(opportunity);
                onClose();
              }}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-sm transition"
            >
              Run Eligibility Check &rarr;
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
