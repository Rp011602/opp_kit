import React from 'react';
import { 
  Briefcase, GraduationCap, Trophy, Calendar, 
  MapPin, CheckCircle, ArrowRight, Info, Award, Edit3, Sparkles
} from 'lucide-react';

export default function OpportunityCard({ opportunity, onSelectForCheck, onViewDetails, onEditOpportunity, isSelected }) {
  const getCategoryTheme = (category) => {
    switch (category) {
      case 'Internships':
        return {
          badgeBg: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: Briefcase,
          accent: 'border-l-blue-600',
          actionBtn: 'bg-blue-600 hover:bg-blue-700 text-white'
        };
      case 'Scholarships':
        return {
          badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          icon: GraduationCap,
          accent: 'border-l-emerald-600',
          actionBtn: 'bg-emerald-600 hover:bg-emerald-700 text-white'
        };
      case 'Competitions':
        return {
          badgeBg: 'bg-purple-50 text-purple-700 border-purple-200',
          icon: Trophy,
          accent: 'border-l-purple-600',
          actionBtn: 'bg-purple-600 hover:bg-purple-700 text-white'
        };
      default:
        return {
          badgeBg: 'bg-slate-100 text-slate-700 border-slate-200',
          icon: Award,
          accent: 'border-l-slate-600',
          actionBtn: 'bg-slate-800 hover:bg-slate-900 text-white'
        };
    }
  };

  const theme = getCategoryTheme(opportunity.category);
  const IconComponent = theme.icon;

  return (
    <div 
      className={`bg-white rounded-2xl border transition-all duration-200 flex flex-col justify-between overflow-hidden group shadow-2xs hover:shadow-md ${
        isSelected 
          ? 'border-blue-600 ring-2 ring-blue-600/20' 
          : 'border-slate-200/90 hover:border-slate-300'
      }`}
    >
      <div className="p-5 sm:p-6">
        
        {/* Top Meta: Category & Badge */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`inline-flex items-center space-x-1.5 text-[11px] font-bold px-2.5 py-1 rounded-full border ${theme.badgeBg}`}>
            <IconComponent className="w-3.5 h-3.5" />
            <span>{opportunity.category}</span>
          </span>
          {opportunity.badge && (
            <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
              {opportunity.badge}
            </span>
          )}
        </div>

        {/* Opportunity Title & Organization */}
        <h3 className="font-extrabold text-slate-900 text-lg group-hover:text-blue-600 transition-colors line-clamp-2 mb-1">
          {opportunity.title}
        </h3>
        <p className="text-xs font-semibold text-slate-500 mb-3">
          {opportunity.organization}
        </p>

        {/* Description */}
        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-4">
          {opportunity.description}
        </p>

        {/* Highlight Criteria Chips */}
        <div className="space-y-2 pt-3 border-t border-slate-100 text-xs text-slate-600">
          
          {/* Allowed Years */}
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-500 font-medium">Eligible Years:</span>
            <span className="font-semibold text-slate-800 truncate max-w-[180px]">
              {opportunity.criteria?.allowedYears?.join(", ") || "All"}
            </span>
          </div>

          {/* Min CGPA */}
          {opportunity.criteria?.minCgpa !== null && opportunity.criteria?.minCgpa !== undefined && (
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500 font-medium">Min CGPA:</span>
              <span className="font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded">
                ≥ {opportunity.criteria.minCgpa}
              </span>
            </div>
          )}

          {/* Stipend / Award */}
          {opportunity.stipendOrPrize && (
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500 font-medium">Award / Stipend:</span>
              <span className="font-bold text-emerald-700 truncate max-w-[180px]">
                {opportunity.stipendOrPrize}
              </span>
            </div>
          )}

          {/* Key skills */}
          {opportunity.criteria?.requiredSkills && opportunity.criteria.requiredSkills.length > 0 && (
            <div className="flex items-center gap-1.5 pt-1 overflow-hidden">
              <span className="text-[10px] text-slate-400 font-medium shrink-0">Skills:</span>
              <div className="flex flex-wrap gap-1 overflow-hidden h-5">
                {opportunity.criteria.requiredSkills.slice(0, 3).map(skill => (
                  <span key={skill} className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-medium">
                    {skill}
                  </span>
                ))}
                {opportunity.criteria.requiredSkills.length > 3 && (
                  <span className="text-[10px] text-slate-500 font-medium">
                    +{opportunity.criteria.requiredSkills.length - 3}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Custom Requirements Chip */}
          {opportunity.criteria?.customRequirements && opportunity.criteria.customRequirements.length > 0 && (
            <div className="flex items-center space-x-1.5 pt-1 text-[10px]">
              <Sparkles className="w-3 h-3 text-indigo-600 shrink-0" />
              <span className="font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
                {opportunity.criteria.customRequirements.length} Custom Criteria
              </span>
            </div>
          )}

        </div>
      </div>

      {/* Footer Actions */}
      <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
        <div className="flex items-center space-x-1 text-[11px] text-slate-500 font-medium">
          <Calendar className="w-3.5 h-3.5 text-slate-400" />
          <span>Deadline: {opportunity.deadline || 'Ongoing'}</span>
        </div>

        <div className="flex items-center space-x-1.5">
          {onEditOpportunity && (
            <button
              type="button"
              onClick={() => onEditOpportunity(opportunity)}
              className="p-2 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition"
              title="Edit opportunity or add custom requirements"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            type="button"
            onClick={() => onViewDetails(opportunity)}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-lg transition"
            title="View full requirement details"
          >
            <Info className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => onSelectForCheck(opportunity)}
            className={`inline-flex items-center space-x-1.5 text-xs font-bold px-3.5 py-2 rounded-xl transition shadow-2xs ${
              isSelected 
                ? 'bg-emerald-600 text-white' 
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isSelected ? (
              <>
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Checking</span>
              </>
            ) : (
              <>
                <span>Check Eligibility</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
