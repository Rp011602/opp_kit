import React, { useState } from 'react';
import { 
  CheckSquare, Square, AlertCircle, FileText, 
  Sparkles, ArrowRight, CheckCircle2, BookmarkCheck
} from 'lucide-react';

export default function ActionChecklist({ actionItems = [], onEditProfile }) {
  // Keep track of user's checked off action items
  const [completedMap, setCompletedMap] = useState({});

  const toggleAction = (id) => {
    setCompletedMap(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const completedCount = actionItems.filter(item => completedMap[item.id]).length;
  const totalCount = actionItems.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 100;

  if (actionItems.length === 0) {
    return (
      <div className="bg-emerald-50 rounded-3xl border border-emerald-200 p-6 sm:p-8 text-center">
        <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-3">
          <CheckCircle2 className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-emerald-950 mb-1">Zero Actionable Gaps!</h3>
        <p className="text-xs text-emerald-800 max-w-md mx-auto">
          Your profile meets all eligibility criteria for this opportunity. You are in a strong position to submit your formal application directly.
        </p>
      </div>
    );
  }

  const getActionBadge = (type) => {
    switch (type) {
      case 'critical_gap':
        return {
          label: 'Eligibility Gap',
          bg: 'bg-rose-100 text-rose-800 border-rose-200',
          icon: AlertCircle
        };
      case 'document':
        return {
          label: 'Document Preparation',
          bg: 'bg-blue-100 text-blue-800 border-blue-200',
          icon: FileText
        };
      case 'missing_info':
        return {
          label: 'Profile Incomplete',
          bg: 'bg-amber-100 text-amber-800 border-amber-200',
          icon: Sparkles
        };
      default:
        return {
          label: 'Action Item',
          bg: 'bg-slate-100 text-slate-800 border-slate-200',
          icon: BookmarkCheck
        };
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
      
      {/* Header & Progress */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Personalized Next Steps</span>
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Action Checklist to Unlock Full Eligibility
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Check off actions as you prepare your documents, acquire skills, or update your profile.
          </p>
        </div>

        {/* Progress Metric */}
        <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 min-w-[200px]">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
            <span className="text-slate-600">Action Progress:</span>
            <span className="text-blue-600">{completedCount} / {totalCount} Done</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Checklist items */}
      <div className="space-y-3">
        {actionItems.map((item, idx) => {
          const isDone = Boolean(completedMap[item.id]);
          const badge = getActionBadge(item.type);
          const BadgeIcon = badge.icon;

          return (
            <div
              key={item.id || idx}
              onClick={() => toggleAction(item.id)}
              className={`p-4 rounded-2xl border cursor-pointer transition flex items-start space-x-3.5 select-none ${
                isDone
                  ? 'bg-slate-50/70 border-slate-200 opacity-75'
                  : 'bg-white border-slate-200 hover:border-blue-400 hover:shadow-2xs'
              }`}
            >
              <button
                type="button"
                className="mt-0.5 text-blue-600 focus:outline-none shrink-0"
                aria-label="Toggle action completed"
              >
                {isDone ? (
                  <CheckSquare className="w-5 h-5 text-emerald-600" />
                ) : (
                  <Square className="w-5 h-5 text-slate-400 hover:text-blue-600" />
                )}
              </button>

              <div className="flex-1 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border flex items-center space-x-1 ${badge.bg}`}>
                    <BadgeIcon className="w-3 h-3" />
                    <span>{badge.label}</span>
                  </span>
                  <h4 className={`text-sm font-bold ${isDone ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                    {item.title}
                  </h4>
                </div>

                <p className={`text-xs leading-relaxed ${isDone ? 'text-slate-400' : 'text-slate-600'}`}>
                  {item.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer call to action */}
      <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-xs text-slate-500">
          Made changes to your skills or documents? Re-sync your profile to recalculate readiness.
        </p>

        <button
          type="button"
          onClick={onEditProfile}
          className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition"
        >
          <span>Update My Profile Now</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
}
