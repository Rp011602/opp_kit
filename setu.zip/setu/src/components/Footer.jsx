import React from 'react';
import { Sparkles, Heart, Shield, RotateCcw } from 'lucide-react';

export default function Footer({ onResetAllData, setActiveTab }) {
  return (
    <footer className="bg-[#0f1f32] text-slate-400 text-xs border-t border-slate-800 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-slate-800">
          
          {/* Brand Col */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-base text-white">
                Opportunity<span className="text-blue-400">Kit</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Empowering students with rule-based, explainable eligibility checks for internships, scholarships, and hackathons. No black-box failures.
            </p>
            <div className="flex items-center space-x-2 text-[11px] text-slate-500">
              <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                SETU 2026 Hackathon
              </span>
              <span>•</span>
              <span className="text-blue-400 font-semibold">PS-03: Forge Realm</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <span className="font-bold uppercase tracking-wider text-slate-200 text-xs block mb-2">
              Navigation
            </span>
            <ul className="space-y-1.5">
              <li>
                <button 
                  onClick={() => setActiveTab('explore')} 
                  className="hover:text-white transition"
                >
                  Explore Opportunities
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('profile')} 
                  className="hover:text-white transition"
                >
                  Student Profile Builder
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('checker')} 
                  className="hover:text-white transition"
                >
                  Smart Eligibility Checker
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('colleges')} 
                  className="hover:text-white transition"
                >
                  For Colleges (Future Vision)
                </button>
              </li>
            </ul>
          </div>

          {/* Privacy & Storage */}
          <div className="space-y-2">
            <span className="font-bold uppercase tracking-wider text-slate-200 text-xs block mb-2">
              Data & Privacy
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              All student profile data is saved locally on your client machine using <code className="text-blue-300">localStorage</code>. Zero external databases or tracking.
            </p>
            <button
              onClick={onResetAllData}
              className="inline-flex items-center space-x-1.5 text-rose-400 hover:text-rose-300 text-[11px] font-semibold mt-2 transition"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset All Cached Data</span>
            </button>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <p>© 2026 OpportunityKit. Designed & Developed for SETU 2026 Hackathon.</p>
          <p className="flex items-center space-x-1">
            <span>Built with React, Vite & Tailwind CSS</span>
          </p>
        </div>

      </div>
    </footer>
  );
}
