import React, { useState, useEffect } from 'react';
import { X, Plus, Sparkles, Trash2, Edit3, CheckCircle2, HelpCircle, Layers } from 'lucide-react';
import { DEFAULT_BRANCHES, YEARS_OF_STUDY, AVAILABLE_DOCUMENTS } from '../types/defaultProfile';

export default function CustomOpportunityModal({ 
  isOpen, 
  onClose, 
  onSaveOpportunity, 
  opportunityToEdit = null 
}) {
  const [category, setCategory] = useState('Internships');
  const [title, setTitle] = useState('');
  const [organization, setOrganization] = useState('');
  const [description, setDescription] = useState('');
  const [stipendOrPrize, setStipendOrPrize] = useState('');
  const [deadline, setDeadline] = useState('');
  
  // Standard Criteria
  const [allowedYears, setAllowedYears] = useState(['3rd Year', '4th Year']);
  const [isAllBranches, setIsAllBranches] = useState(true);
  const [allowedBranches, setAllowedBranches] = useState([]);
  const [minCgpa, setMinCgpa] = useState('');
  const [skillsText, setSkillsText] = useState('React, JavaScript');
  const [requiredDocuments, setRequiredDocuments] = useState(['Updated Resume / CV', 'College ID Card']);
  const [requiresGithub, setRequiresGithub] = useState(true);
  const [maxFamilyIncomeLpa, setMaxFamilyIncomeLpa] = useState('');
  const [minTeamSize, setMinTeamSize] = useState('');
  const [maxTeamSize, setMaxTeamSize] = useState('');

  // DYNAMIC CUSTOM REQUIREMENTS STATE
  const [customRequirements, setCustomRequirements] = useState([]);
  
  // New requirement draft form
  const [newReqName, setNewReqName] = useState('');
  const [newReqType, setNewReqType] = useState('Yes/No'); // 'Number', 'Text', 'Skill', 'Document', 'Yes/No'
  const [newReqOperator, setNewReqOperator] = useState('>=');
  const [newReqValue, setNewReqValue] = useState('Yes');
  const [newReqExplanation, setNewReqExplanation] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // Sync state if opportunityToEdit is provided
  useEffect(() => {
    if (opportunityToEdit) {
      setCategory(opportunityToEdit.category || 'Internships');
      setTitle(opportunityToEdit.title || '');
      setOrganization(opportunityToEdit.organization || '');
      setDescription(opportunityToEdit.description || '');
      setStipendOrPrize(opportunityToEdit.stipendOrPrize || '');
      setDeadline(opportunityToEdit.deadline || '');

      const crit = opportunityToEdit.criteria || {};
      setAllowedYears(crit.allowedYears || ['1st Year', '2nd Year', '3rd Year', '4th Year']);
      const branches = crit.allowedBranches || ['Any'];
      setIsAllBranches(branches.includes('Any'));
      setAllowedBranches(branches.filter(b => b !== 'Any'));
      setMinCgpa(crit.minCgpa !== null && crit.minCgpa !== undefined ? String(crit.minCgpa) : '');
      setSkillsText((crit.requiredSkills || []).join(', '));
      setRequiredDocuments(crit.requiredDocuments || []);
      setRequiresGithub(Boolean(crit.requiresGithub));
      setMaxFamilyIncomeLpa(crit.maxFamilyIncomeLpa !== null && crit.maxFamilyIncomeLpa !== undefined ? String(crit.maxFamilyIncomeLpa) : '');
      setMinTeamSize(crit.minTeamSize ? String(crit.minTeamSize) : '');
      setMaxTeamSize(crit.maxTeamSize ? String(crit.maxTeamSize) : '');
      setCustomRequirements(crit.customRequirements || []);
    } else {
      // Reset to fresh draft
      setCategory('Internships');
      setTitle('');
      setOrganization('');
      setDescription('');
      setStipendOrPrize('');
      setDeadline('');
      setAllowedYears(['3rd Year', '4th Year']);
      setIsAllBranches(true);
      setAllowedBranches([]);
      setMinCgpa('');
      setSkillsText('React, JavaScript');
      setRequiredDocuments(['Updated Resume / CV', 'College ID Card']);
      setRequiresGithub(true);
      setMaxFamilyIncomeLpa('');
      setMinTeamSize('');
      setMaxTeamSize('');
      setCustomRequirements([]);
    }
  }, [opportunityToEdit, isOpen]);

  if (!isOpen) return null;

  const handleToggleYear = (year) => {
    if (allowedYears.includes(year)) {
      setAllowedYears(allowedYears.filter(y => y !== year));
    } else {
      setAllowedYears([...allowedYears, year]);
    }
  };

  const handleToggleBranch = (branch) => {
    if (allowedBranches.includes(branch)) {
      setAllowedBranches(allowedBranches.filter(b => b !== branch));
    } else {
      setAllowedBranches([...allowedBranches, branch]);
    }
  };

  const handleToggleDoc = (doc) => {
    if (requiredDocuments.includes(doc)) {
      setRequiredDocuments(requiredDocuments.filter(d => d !== doc));
    } else {
      setRequiredDocuments([...requiredDocuments, doc]);
    }
  };

  // Add Dynamic Custom Requirement
  const handleAddCustomRequirement = (e) => {
    e.preventDefault();
    if (!newReqName.trim()) {
      alert("Please enter a requirement name.");
      return;
    }

    let formattedValue = newReqValue;
    if (newReqType === 'Number') {
      if (isNaN(Number(newReqValue)) || newReqValue === '') {
        alert("Please enter a valid numeric value for this requirement.");
        return;
      }
      formattedValue = Number(newReqValue);
    }

    const newReq = {
      id: `cust_req_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      name: newReqName.trim(),
      type: newReqType,
      operator: newReqType === 'Number' ? newReqOperator : newReqType === 'Text' ? (newReqOperator || 'contains') : '==',
      value: formattedValue,
      explanation: newReqExplanation.trim(),
      isCritical: false
    };

    setCustomRequirements(prev => [...prev, newReq]);

    // Reset draft fields
    setNewReqName('');
    setNewReqExplanation('');
    if (newReqType === 'Number') setNewReqValue('1');
    else if (newReqType === 'Yes/No') setNewReqValue('Yes');
    else setNewReqValue('');
    setShowAddForm(false);
  };

  const handleRemoveCustomRequirement = (idToRemove) => {
    setCustomRequirements(prev => prev.filter(r => r.id !== idToRemove));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || !organization.trim()) {
      alert("Please fill in the title and organization.");
      return;
    }

    const skillsArray = skillsText
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    const oppId = opportunityToEdit?.id || `custom-opp-${Date.now()}`;

    const savedOpp = {
      id: oppId,
      category,
      title: title.trim(),
      organization: organization.trim(),
      badge: opportunityToEdit?.badge || 'Custom Added',
      deadline: deadline || '2026-12-31',
      stipendOrPrize: stipendOrPrize.trim() || 'Undisclosed',
      description: description.trim() || 'Opportunity with custom eligibility rules.',
      criteria: {
        allowedYears: allowedYears.length > 0 ? allowedYears : ['Any'],
        allowedBranches: isAllBranches ? ['Any'] : (allowedBranches.length > 0 ? allowedBranches : ['Any']),
        minCgpa: minCgpa ? parseFloat(minCgpa) : null,
        requiredSkills: skillsArray,
        requiredDocuments,
        requiresGithub,
        maxFamilyIncomeLpa: maxFamilyIncomeLpa ? parseFloat(maxFamilyIncomeLpa) : null,
        minTeamSize: minTeamSize ? parseInt(minTeamSize, 10) : null,
        maxTeamSize: maxTeamSize ? parseInt(maxTeamSize, 10) : null,
        customRequirements // DYNAMIC CUSTOM REQUIREMENTS ARRAY
      }
    };

    onSaveOpportunity(savedOpp);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white w-full max-w-3xl rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              {opportunityToEdit ? <Edit3 className="w-4 h-4 text-white" /> : <Plus className="w-4 h-4 text-white" />}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {opportunityToEdit ? `Edit Opportunity & Custom Rules` : `Create Opportunity & Custom Requirements`}
              </h2>
              <p className="text-xs text-slate-300">
                Define standard eligibility cutoffs + add flexible custom requirements (Number, Text, Skill, Document, Yes/No)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 sm:p-6 space-y-6 text-xs text-slate-700">
          
          {/* Category & Title */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold text-slate-800 uppercase tracking-wider mb-1.5">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="Internships">Internships</option>
                <option value="Scholarships">Scholarships</option>
                <option value="Competitions">Competitions</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-800 uppercase tracking-wider mb-1.5">Opportunity Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Google STEP Internship 2026"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          {/* Organization & Stipend/Prize */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-800 uppercase tracking-wider mb-1.5">Company / Organization *</label>
              <input
                type="text"
                required
                value={organization}
                onChange={(e) => setOrganization(e.target.value)}
                placeholder="e.g. Google India"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 uppercase tracking-wider mb-1.5">Stipend / Prize Pool / Grant</label>
              <input
                type="text"
                value={stipendOrPrize}
                onChange={(e) => setStipendOrPrize(e.target.value)}
                placeholder="e.g. ₹60,000 / month or ₹1,00,000 Prize"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          {/* Description & Deadline */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-800 uppercase tracking-wider mb-1.5">Short Description</label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Role summary, expected deliverables, or program objectives..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-800 uppercase tracking-wider mb-1.5">Application Deadline</label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          {/* DYNAMIC CUSTOM REQUIREMENTS SECTION (HIGHLIGHT IMPROVEMENT) */}
          <div className="pt-4 border-t-2 border-blue-100 bg-blue-50/40 p-4 sm:p-5 rounded-2xl border">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                  Dynamic Feature
                </span>
                <h3 className="text-sm font-extrabold text-slate-900 mt-1 flex items-center space-x-1.5">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>Custom / Specific Opportunity Requirements ({customRequirements.length})</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  Add non-standard requirements such as age limits, citizenship, state domicile, specific tools, or custom conditions.
                </p>
              </div>

              {!showAddForm && (
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(true);
                    setNewReqType('Yes/No');
                    setNewReqValue('Yes');
                  }}
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition shrink-0 self-start sm:self-auto"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Custom Requirement</span>
                </button>
              )}
            </div>

            {/* Existing custom requirements list */}
            {customRequirements.length > 0 ? (
              <div className="space-y-2 mb-3">
                {customRequirements.map((req, index) => (
                  <div
                    key={req.id || index}
                    className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5 flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-black uppercase px-2 py-0.2 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                          {req.type}
                        </span>
                        <h4 className="font-bold text-slate-900 text-xs truncate">
                          {req.name}
                        </h4>
                      </div>
                      <div className="flex items-center space-x-2 text-[11px] text-slate-600">
                        <span className="font-semibold text-blue-700">
                          Condition: {req.type === 'Number' ? `${req.operator || '>='} ${req.value}` : req.type === 'Text' ? `${req.operator || 'contains'} "${req.value}"` : req.value}
                        </span>
                        {req.explanation && (
                          <span className="text-slate-400 truncate max-w-xs">
                            • {req.explanation}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveCustomRequirement(req.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition shrink-0"
                      title="Remove requirement"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              !showAddForm && (
                <div className="p-3 bg-white/80 rounded-xl border border-dashed border-slate-300 text-center text-[11px] text-slate-500">
                  No custom requirements added yet. Click "+ Add Custom Requirement" to define non-standard criteria.
                </div>
              )
            )}

            {/* Inline Add Requirement Form */}
            {showAddForm && (
              <div className="p-4 bg-white rounded-2xl border-2 border-blue-400 shadow-xs space-y-3 mt-3 animate-fadeIn">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="font-bold text-slate-800 text-xs">Define New Requirement Rule</span>
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="text-slate-400 hover:text-slate-600 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Requirement Name *</label>
                    <input
                      type="text"
                      value={newReqName}
                      onChange={(e) => setNewReqName(e.target.value)}
                      placeholder="e.g. State Domicile, Prior Work Exp, Has Passport"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Requirement Type *</label>
                    <select
                      value={newReqType}
                      onChange={(e) => {
                        const t = e.target.value;
                        setNewReqType(t);
                        if (t === 'Number') {
                          setNewReqOperator('>=');
                          setNewReqValue('1');
                        } else if (t === 'Text') {
                          setNewReqOperator('contains');
                          setNewReqValue('');
                        } else if (t === 'Yes/No') {
                          setNewReqOperator('==');
                          setNewReqValue('Yes');
                        } else {
                          setNewReqValue('');
                        }
                      }}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-blue-500/20"
                    >
                      <option value="Yes/No">Yes / No Confirmation</option>
                      <option value="Number">Number (Threshold / Cutoff)</option>
                      <option value="Text">Text Match (State, Cohort, Track)</option>
                      <option value="Skill">Specific Skill</option>
                      <option value="Document">Specific Document</option>
                    </select>
                  </div>
                </div>

                {/* Condition Inputs depending on Type */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <span className="block font-bold text-slate-700 text-[11px] uppercase tracking-wider">Required Condition</span>

                  {newReqType === 'Number' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] text-slate-500 font-semibold mb-1">Comparison Operator</label>
                        <select
                          value={newReqOperator}
                          onChange={(e) => setNewReqOperator(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                        >
                          <option value=">=">&ge; Greater than or equal (Minimum)</option>
                          <option value="<=">&le; Less than or equal (Maximum)</option>
                          <option value="==">= Exactly equal to</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 font-semibold mb-1">Target Numeric Value</label>
                        <input
                          type="number"
                          step="any"
                          value={newReqValue}
                          onChange={(e) => setNewReqValue(e.target.value)}
                          placeholder="e.g. 6 or 25"
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                        />
                      </div>
                    </div>
                  )}

                  {newReqType === 'Text' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] text-slate-500 font-semibold mb-1">Match Type</label>
                        <select
                          value={newReqOperator}
                          onChange={(e) => setNewReqOperator(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                        >
                          <option value="contains">Contains (Case-insensitive)</option>
                          <option value="exact">Exact Match</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 font-semibold mb-1">Target Value</label>
                        <input
                          type="text"
                          value={newReqValue}
                          onChange={(e) => setNewReqValue(e.target.value)}
                          placeholder="e.g. Maharashtra or Female"
                          className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                        />
                      </div>
                    </div>
                  )}

                  {newReqType === 'Yes/No' && (
                    <div>
                      <label className="block text-[10px] text-slate-500 font-semibold mb-1">Required Student Answer</label>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setNewReqValue('Yes')}
                          className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition ${
                            newReqValue === 'Yes' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          Must be Yes
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewReqValue('No')}
                          className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition ${
                            newReqValue === 'No' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          Must be No
                        </button>
                      </div>
                    </div>
                  )}

                  {newReqType === 'Skill' && (
                    <div>
                      <label className="block text-[10px] text-slate-500 font-semibold mb-1">Required Skill Name</label>
                      <input
                        type="text"
                        value={newReqValue}
                        onChange={(e) => setNewReqValue(e.target.value)}
                        placeholder="e.g. GraphQL, TensorFlow, Docker"
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                      />
                    </div>
                  )}

                  {newReqType === 'Document' && (
                    <div>
                      <label className="block text-[10px] text-slate-500 font-semibold mb-1">Required Document Name</label>
                      <input
                        type="text"
                        value={newReqValue}
                        onChange={(e) => setNewReqValue(e.target.value)}
                        placeholder="e.g. No Objection Certificate (NOC), State Domicile"
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                      />
                    </div>
                  )}
                </div>

                {/* Optional Explanation */}
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Optional Short Explanation / Reason</label>
                  <input
                    type="text"
                    value={newReqExplanation}
                    onChange={(e) => setNewReqExplanation(e.target.value)}
                    placeholder="e.g. Required by government nodal authority for security clearance"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={handleAddCustomRequirement}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    Add to Requirements List
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Standard Eligibility Rules Section */}
          <div className="pt-2 border-t border-slate-200">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 mb-3 flex items-center space-x-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              <span>Standard Criteria & Filters</span>
            </h3>

            {/* Allowed Years */}
            <div className="mb-4">
              <label className="block font-bold text-slate-700 mb-1.5">Eligible Academic Years</label>
              <div className="flex flex-wrap gap-2">
                {YEARS_OF_STUDY.map(y => (
                  <button
                    key={y}
                    type="button"
                    onClick={() => handleToggleYear(y)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold border transition ${
                      allowedYears.includes(y)
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {y}
                  </button>
                ))}
              </div>
            </div>

            {/* Allowed Branches */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-slate-700">Eligible Branches / Disciplines</label>
                <label className="flex items-center space-x-1.5 cursor-pointer text-xs font-semibold text-blue-600">
                  <input
                    type="checkbox"
                    checked={isAllBranches}
                    onChange={(e) => setIsAllBranches(e.target.checked)}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span>Open to All Branches</span>
                </label>
              </div>
              {!isAllBranches && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 p-3 bg-slate-50 rounded-xl border border-slate-200 max-h-32 overflow-y-auto">
                  {DEFAULT_BRANCHES.map(b => (
                    <label key={b} className="flex items-center space-x-2 text-[11px] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allowedBranches.includes(b)}
                        onChange={() => handleToggleBranch(b)}
                        className="rounded text-blue-600 focus:ring-blue-500"
                      />
                      <span className="truncate">{b}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Min CGPA & Required Skills */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">Min CGPA Cutoff</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="10"
                  value={minCgpa}
                  onChange={(e) => setMinCgpa(e.target.value)}
                  placeholder="e.g. 7.5 (leave empty if none)"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1.5">Required Skills (Comma separated)</label>
                <input
                  type="text"
                  value={skillsText}
                  onChange={(e) => setSkillsText(e.target.value)}
                  placeholder="e.g. React, Python, Data Structures & Algorithms"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            {/* Required Documents */}
            <div className="mb-4">
              <label className="block font-bold text-slate-700 mb-1.5">Mandatory Verification Documents</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {AVAILABLE_DOCUMENTS.map(doc => (
                  <label key={doc} className="flex items-center space-x-2 cursor-pointer text-[11px]">
                    <input
                      type="checkbox"
                      checked={requiredDocuments.includes(doc)}
                      onChange={() => handleToggleDoc(doc)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span>{doc}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Extra Conditional Rules */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div>
                <label className="flex items-center space-x-2 cursor-pointer font-bold text-slate-700 mb-1">
                  <input
                    type="checkbox"
                    checked={requiresGithub}
                    onChange={(e) => setRequiresGithub(e.target.checked)}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span>Requires GitHub / Code URL</span>
                </label>
                <p className="text-[10px] text-slate-400">Verifies student submitted repo</p>
              </div>

              {category === 'Scholarships' && (
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Max Family Income (LPA)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={maxFamilyIncomeLpa}
                    onChange={(e) => setMaxFamilyIncomeLpa(e.target.value)}
                    placeholder="e.g. 5.0"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              )}

              {category === 'Competitions' && (
                <div className="sm:col-span-2 grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Min Team Size</label>
                    <input
                      type="number"
                      min="1"
                      value={minTeamSize}
                      onChange={(e) => setMinTeamSize(e.target.value)}
                      placeholder="e.g. 2"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Max Team Size</label>
                    <input
                      type="number"
                      min="1"
                      value={maxTeamSize}
                      onChange={(e) => setMaxTeamSize(e.target.value)}
                      placeholder="e.g. 4"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                </div>
              )}
            </div>

          </div>

          {/* Modal Action Buttons */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-semibold text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-sm transition"
            >
              {opportunityToEdit ? "Save Changes & Recheck" : "Save Opportunity & Run Checker"}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
